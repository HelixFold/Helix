/** Working with `string`, which is `readonly u8[]`: UTF-8 bytes and a length. */

/** Whether `a` and `b` hold the same bytes. */
export function equal(a: string, b: string): bool {
    if (a.len != b.len) return false;
    for (const c, i of a) {
        if (c != b[i]) return false;
    }
    return true;
}

export function startsWith(text: string, prefix: string): bool {
    return prefix.len <= text.len && equal(text[0..prefix.len], prefix);
}

export function endsWith(text: string, suffix: string): bool {
    return suffix.len <= text.len && equal(text[text.len - suffix.len..], suffix);
}

/** Byte offset of the first `needle` in `text`, or null. */
export function indexOf(text: string, needle: string): ?usize {
    if (needle.len > text.len) return null;
    for (const i of 0..=text.len - needle.len) {
        if (equal(text[i..i + needle.len], needle)) return i;
    }
    return null;
}

function isSpace(c: u8): bool {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r';
}

/** `text` without leading and trailing whitespace. */
export function trim(text: string): string {
    let start: usize = 0;
    let end = text.len;
    while (start < end && isSpace(text[start])) start++;
    while (end > start && isSpace(text[end - 1])) end--;
    return text[start..end];
}

export error ParseIntError { Empty, InvalidDigit, Overflow }

/** A decimal integer with an optional leading `-`. */
export function parseInt(text: string): i64 | ParseIntError {
    if (text.len == 0) throw ParseIntError.Empty;
    const negative = text[0] == '-';
    const digits = negative ? text[1..] : text;
    if (digits.len == 0) throw ParseIntError.Empty;

    let value: i64 = 0;
    for (const c of digits) {
        if (c < '0' || c > '9') throw ParseIntError.InvalidDigit;
        const digit = (c - '0') as i64;
        // Accumulate as a negative number: its range is one larger, so the minimum i64 parses too.
        if (value < (-9223372036854775807 - 1 + digit) / 10) throw ParseIntError.Overflow;
        value = value * 10 - digit;
    }
    if (negative) return value;
    if (value == -9223372036854775807 - 1) throw ParseIntError.Overflow;
    return -value;
}

/** The pieces of `text` around each `separator`: `split("a,b,,c", ",")` gives "a", "b", "", "c". */
export function split(text: string, separator: string): Split {
    return Split { rest: text, separator, done: false };
}

/** An iterator over the pieces of a string; see `split`. An empty separator gives the whole text as one piece. */
export struct Split {
    rest: string,
    separator: string,
    done: bool,

    next(this: *Split): ?string {
        if (this.done) return null;
        if (this.separator.len > 0) {
            if (const at = indexOf(this.rest, this.separator)) {
                const piece = this.rest[0..at];
                this.rest = this.rest[at + this.separator.len..];
                return piece;
            }
        }
        this.done = true;
        return this.rest;
    }
}

/** The lines of `text`, without their `\n` or `\r\n`. A newline at the very end doesn't start another line. */
export function lines(text: string): Lines {
    return Lines { rest: text };
}

/** An iterator over the lines of a string; see `lines`. */
export struct Lines {
    rest: string,

    next(this: *Lines): ?string {
        if (this.rest.len == 0) return null;
        let end: usize = 0;
        while (end < this.rest.len && this.rest[end] != '\n') end++;
        const line = this.rest[0..end];
        this.rest = end < this.rest.len ? this.rest[end + 1..] : this.rest[end..];
        return endsWith(line, "\r") ? line[0..line.len - 1] : line;
    }
}
