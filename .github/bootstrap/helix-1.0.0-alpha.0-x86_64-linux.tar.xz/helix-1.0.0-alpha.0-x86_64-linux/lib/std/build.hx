/**
 * The `Build` that `build.hx` fills in, and the runner behind `helix build`.
 *
 *   // helix.jsonc: "bin": { "app": "src/main.hx" }
 *
 *   // build.hx
 *   import { Build } from "std/build";
 *
 *   export function build(b: *Build): void | Error {
 *       const tracing = b.optionBool("tracing", "Log every request") ?? false;
 *
 *       const config = try b.addOptions("config");      // `import { tracing } from "config"` in the program
 *       try config.addBool("tracing", tracing);
 *
 *       const app = try b.bin("app");                   // helix.jsonc's program, to add to
 *       try app.addOptions(config);
 *   }
 *
 * helix.jsonc declares the programs: the runner always builds and installs each `bin`, gives the first a `run`
 * step and tests `src/` in a `test` step, with or without a build.hx. build.hx adds to that: options, C sources,
 * code generators, programs that aren't shipped, steps of its own (a `run` or `test` of its own replaces the
 * default one). `--target` and `--mode` are the runner's, read as `b.target` and `b.mode`; `-Dname=value` is only
 * for options build.hx declares.
 *
 * `helix build` compiles build.hx with this module's runner and runs it. `build` only records options, artifacts
 * and steps; the runner then performs the steps asked for on the command line (`install` when none are), each
 * one's dependencies first, by calling `helix` and `helix cc`. `helix build --help` lists the steps and options.
 * See docs/design/build.md.
 */

import { Allocator, ArenaAllocator, alloc, cAllocator } from "./heap";
import { ArrayList } from "./list";
import { Init, exit } from "./process";
import * as process from "./process";
import * as fmt from "./fmt";
import * as fs from "./fs";
import { equal, startsWith, indexOf, split, lines, parseInt } from "./text";

/* ---- build.hx ---- */

export error BuildError { UnknownStep, StepFailed, BadOption, BadPackageList }

/** The build modes, as `helix build --mode` names them. */
export enum Mode { Debug, ReleaseSafe, ReleaseFast, ReleaseSmall }

const MODES: Mode[4] = [Mode.Debug, Mode.ReleaseSafe, Mode.ReleaseFast, Mode.ReleaseSmall];

function modeName(mode: Mode): string {
    return switch (mode) {
        case Mode.Debug: "debug";
        case Mode.ReleaseSafe: "release-safe";
        case Mode.ReleaseFast: "release-fast";
        case Mode.ReleaseSmall: "release-small";
    };
}

/** The C compiler's optimization flag for a mode. */
function cOptimization(mode: Mode): string {
    return switch (mode) {
        case Mode.Debug: "-O0";
        case Mode.ReleaseSafe: "-O2";
        case Mode.ReleaseFast: "-O3";
        case Mode.ReleaseSmall: "-Os";
    };
}

export struct ExecutableOptions {
    name: string,
    root: string,               // the file with `main`
    target: ?string = null,     // `arch-os[-abi]`; `native` = this machine; null = the build's `--target`
    mode: ?Mode = null,         // null = the build's `--mode`
    strip: bool = false,        // leave out debug info and symbols
    cpu: ?string = null,        // `native`, `generic` or a CPU name (`apple-m1`, `x86-64-v3`); null = native for
                                // this machine, generic for another target
    linkerScript: ?string = null,   // `<arch>-freestanding`: where the program goes in memory (default: QEMU `virt`,
                                    // or for Cortex-M one made from helix.jsonc's `chip`)
}

export struct TestOptions {
    root: string,               // a spec file, or a folder of them
    target: ?string = null,     // null = the build's `--target`
    mode: ?Mode = null,         // null = the build's `--mode`
    linkWith: ?Artifact = null, // also link this artifact's C files and libraries, for specs that import its code
}

export struct CSources {
    files: readonly string[],
    flags: readonly string[] = [],
}

struct CFile {
    path: string,
    flags: readonly string[],
}

struct ArtifactData {
    name: string,
    root: string,
    target: ?string,
    mode: Mode,
    strip: bool,
    cpu: ?string,
    linkerScript: ?string,
    options: ArrayList<usize>,  // the `addOptions` modules it imports
    cFiles: ArrayList<CFile>,
    includeDirs: ArrayList<string>,
    libraries: ArrayList<string>,
    output: string,             // where it's built, in .helix-cache
    built: bool,
}

/** An executable `build` asked for. A handle: it stays valid as more artifacts are added. */
export struct Artifact {
    b: *Build,
    index: usize,

    /** C files compiled with the artifact's target and mode, and linked into it. */
    addCSources(this: Artifact, sources: CSources): void | Error {
        for (const file of sources.files) {
            try this.b.artifacts.items[this.index].cFiles.append(CFile { path: file, flags: sources.flags });
        }
    }

    /** A folder to search for `#include`s in this artifact's C files. */
    addIncludeDir(this: Artifact, path: string): void | Error {
        try this.b.artifacts.items[this.index].includeDirs.append(path);
    }

    /** Links a library the system provides: `linkSystemLibrary("z")` is `-lz`. */
    linkSystemLibrary(this: Artifact, name: string): void | Error {
        try this.b.artifacts.items[this.index].libraries.append(name);
    }

    /** Lets the artifact's code import `options` by its name: `import { tracing } from "config"`. */
    addOptions(this: Artifact, options: Options): void | Error {
        try this.b.artifacts.items[this.index].options.append(options.index);
    }
}

struct OptionsData {
    name: string,
    lines: ArrayList<string>,   // `export const name: type = value;`
}

/** Values from the build that the program can read as constants, from a module `build.hx` generates. */
export struct Options {
    b: *Build,
    index: usize,

    addBool(this: Options, name: string, value: bool): void | Error {
        try this.add(try fmt.alloc(this.b.a, `export const ${name}: bool = ${value};`));
    }

    addInt(this: Options, name: string, value: i64): void | Error {
        try this.add(try fmt.alloc(this.b.a, `export const ${name}: i64 = ${value};`));
    }

    addString(this: Options, name: string, value: string): void | Error {
        try this.add(try fmt.alloc(this.b.a, `export const ${name}: string = "${try escape(this.b.a, value)}";`));
    }

    add(this: Options, line: string): void | Error {
        try this.b.optionModules.items[this.index].lines.append(line);
    }
}

/** `text` with `\`, `"` and control characters escaped, for a Helix string literal. */
function escape(a: dyn Allocator, text: string): string | Error {
    let size: usize = 0;
    for (const c of text) size += c == '\\' || c == '"' || c == '\n' || c == '\t' || c == '\r' ? 2 : 1;
    const out = try alloc<u8>(a, size);
    let n: usize = 0;
    for (const c of text) {
        const pair: ?u8 = c == '\\' ? '\\' : c == '"' ? '"' : c == '\n' ? 'n' : c == '\t' ? 't' : c == '\r' ? 'r' : null;
        if (const p = pair) {
            out[n] = '\\';
            out[n + 1] = p;
            n += 2;
        } else {
            out[n] = c;
            n += 1;
        }
    }
    return out;
}

enum StepKind { Group, Install, Run, Test, Command }

struct StepData {
    name: string,
    description: string,
    kind: StepKind,
    artifact: usize,            // Install, Run
    test: TestOptions,          // Test
    argv: readonly string[],    // Command; Install: the folder in helix-out
    deps: ArrayList<usize>,
    done: bool,
}

/** A step: named ones can be asked for with `helix build <name>`. */
export struct Step {
    b: *Build,
    index: usize,

    /** Makes this step run `other` first. */
    dependOn(this: Step, other: Step): void | Error {
        try this.b.steps.items[this.index].deps.append(other.index);
    }
}

struct Define {
    name: string,
    value: string,
}

/** An option `build.hx` declared, for `--help` and to catch misspelled `-D`s. */
struct Declared {
    name: string,
    kind: string,
    description: string,
}

/** What `build.hx` describes. `build(b)` adds to it; the runner then performs the steps. */
export struct Build {
    a: dyn Allocator,
    helix: string,
    verbose: bool,
    /** `--target arch-os[-abi]`: what the build is for; null = this machine, or helix.jsonc's `chip`. */
    target: ?string,
    /** `--mode`: debug when it isn't given. */
    mode: Mode,
    defines: ArrayList<Define>,
    declared: ArrayList<Declared>,
    bins: ArrayList<Define>,        // helix.jsonc's `bin`: name and root
    optionModules: ArrayList<OptionsData>,
    runArgs: readonly string[],
    artifacts: ArrayList<ArtifactData>,
    steps: ArrayList<StepData>,
    compiled: ArrayList<string>,    // C objects already compiled during this run
    defaults: ArrayList<usize>,     // the runner's own `run` and `test` steps, which build.hx's replace

    /** The value of `-Dname=...`, recording the option for `--help`. */
    declare(this: *Build, name: string, kind: string, description: string): ?string {
        let known = false;
        for (const d of this.declared.items) known = known || equal(d.name, name);
        if (!known) {
            this.declared.append(Declared { name, kind, description }) catch {
                eprintln("error: out of memory");
                exit(2);
            };
        }
        for (const d of this.defines.items) {
            if (equal(d.name, name)) return d.value;
        }
        return null;
    }

    /** `-Dname` or `-Dname=true|false`, or null when it isn't given. */
    optionBool(this: *Build, name: string, description: string): ?bool {
        if (const value = this.declare(name, "bool", description)) {
            if (equal(value, "true")) return true;
            if (equal(value, "false")) return false;
            eprintln(`error: -D${name} takes true or false, not '${value}'`);
            exit(2);
        }
        return null;
    }

    /** `-Dname=text`, or null when it isn't given. */
    optionString(this: *Build, name: string, description: string): ?string {
        return this.declare(name, "string", description);
    }

    /** `-Dname=123`, or null when it isn't given. */
    optionInt(this: *Build, name: string, description: string): ?i64 {
        if (const value = this.declare(name, "int", description)) {
            return parseInt(value) catch {
                eprintln(`error: -D${name} takes a whole number, not '${value}'`);
                exit(2);
            };
        }
        return null;
    }

    /** A module of constants named `name` that artifacts can import (`app.addOptions(options)`). */
    addOptions(this: *Build, name: string): Options | Error {
        try this.optionModules.append(OptionsData { name, lines: ArrayList<string>.init(this.a) });
        return Options { b: this, index: this.optionModules.items.len - 1 };
    }

    /** The program helix.jsonc's `bin` names `name`, which the runner already builds and installs. */
    bin(this: *Build, name: string): Artifact | Error {
        for (const art, i of this.artifacts.items) {
            if (i < this.bins.items.len && equal(art.name, name)) return Artifact { b: this, index: i };
        }
        eprintln(`error: build.hx asks for the program "${name}", which isn't in helix.jsonc's "bin"`);
        throw BuildError.BadOption;
    }

    /** An executable built from `root`, which has `main`. Nothing is built until a step needs it. */
    addExecutable(this: *Build, options: ExecutableOptions): Artifact | Error {
        const target = options.target ?? this.target;
        const mode = options.mode ?? this.mode;
        for (const art, i of this.artifacts.items) {   // the same program for another target or mode is a new one
            if (!equal(art.name, options.name) || !sameTarget(art.target, target) || art.mode != mode) continue;
            if (i < this.bins.items.len) {
                eprintln(`error: "${options.name}" is a program in helix.jsonc's "bin"; build.hx adds to it with b.bin("${options.name}")`);
                throw BuildError.BadOption;
            }
            // asked for again (a release's target that `--target` also names): one artifact, built once
            if (equal(art.root, options.root) && art.strip == options.strip) return Artifact { b: this, index: i };
            eprintln(`error: build.hx adds the executable "${options.name}" twice, from ${art.root} and ${options.root}`);
            throw BuildError.BadOption;
        }
        const output = try fmt.alloc(this.a, `${try cacheDir(this, target, mode)}/${options.name}${executableSuffix(target)}`);
        try this.artifacts.append(ArtifactData {
            name: options.name,
            root: options.root,
            target,
            mode,
            strip: options.strip,
            cpu: options.cpu,
            linkerScript: options.linkerScript,
            options: ArrayList<usize>.init(this.a),
            cFiles: ArrayList<CFile>.init(this.a),
            includeDirs: ArrayList<string>.init(this.a),
            libraries: ArrayList<string>.init(this.a),
            output,
            built: false,
        });
        return Artifact { b: this, index: this.artifacts.items.len - 1 };
    }

    /** Copies the artifact into helix-out/bin/ as part of the default `install` step. */
    install(this: *Build, artifact: Artifact): void | Error {
        const step = try this.addInstall(artifact, "bin");
        try this.steps.items[0].deps.append(step.index);
    }

    /**
     * A step that builds the artifact and copies it into helix-out/`dir`/, for a step of its own to depend on:
     * `release.dependOn(try b.addInstall(app, "release/x86_64-linux"))`.
     */
    addInstall(this: *Build, artifact: Artifact, dir: string): Step | Error {
        const argv = try alloc<string>(this.a, 1);
        argv[0] = dir;
        const index = try this.addStep(StepData {
            name: "", description: "", kind: StepKind.Install, artifact: artifact.index, test: TestOptions { root: "" },
            argv, deps: ArrayList<usize>.init(this.a), done: false,
        });
        return Step { b: this, index };
    }

    /** The `run` step: builds the artifact and runs it with the arguments after `--`. */
    addRunStep(this: *Build, artifact: Artifact): void | Error {
        void try this.addStep(StepData {
            name: "run", description: "Build and run the program; arguments after `--` go to it", kind: StepKind.Run,
            artifact: artifact.index, test: TestOptions { root: "" }, argv: [], deps: ArrayList<usize>.init(this.a),
            done: false,
        });
    }

    /** The `test` step: `helix test` on a spec file or a folder, with the package's dependencies available. */
    addTestStep(this: *Build, options: TestOptions): void | Error {
        void try this.addStep(StepData {
            name: "test", description: "Run the tests", kind: StepKind.Test, artifact: 0, test: options, argv: [],
            deps: ArrayList<usize>.init(this.a), done: false,
        });
    }

    /** A named step that does nothing itself: give it work with `dependOn`. */
    step(this: *Build, name: string, description: string): Step | Error {
        const index = try this.addStep(StepData {
            name, description, kind: StepKind.Group, artifact: 0, test: TestOptions { root: "" }, argv: [],
            deps: ArrayList<usize>.init(this.a), done: false,
        });
        return Step { b: this, index };
    }

    /** A step that runs a program, like a code generator. It fails when the program exits with a status other than 0. */
    addSystemCommand(this: *Build, argv: readonly string[]): Step | Error {
        const index = try this.addStep(StepData {
            name: "", description: "", kind: StepKind.Command, artifact: 0, test: TestOptions { root: "" }, argv,
            deps: ArrayList<usize>.init(this.a), done: false,
        });
        return Step { b: this, index };
    }

    addStep(this: *Build, data: StepData): usize | Error {
        if (data.name.len > 0) {
            for (const s, i of this.steps.items) {
                if (!equal(s.name, data.name)) continue;
                for (const d, j of this.defaults.items) {   // build.hx's own `run` or `test` replaces the runner's
                    if (d != i) continue;
                    this.steps.items[i] = data;
                    this.defaults.items[j] = this.defaults.items[this.defaults.items.len - 1];
                    void this.defaults.pop();
                    return i;
                }
                eprintln(`error: build.hx adds the step "${data.name}" twice`);
                throw BuildError.BadOption;
            }
        }
        try this.steps.append(data);
        return this.steps.items.len - 1;
    }
}

/* ---- the runner ---- */

/** Runs a command, printing it first with `-v`. A non-zero status fails the step. */
function command(b: *Build, argv: readonly string[]): void | Error {
    if (b.verbose) {
        for (const word, i of argv) {
            if (i > 0) eprint(" ");
            eprint(word);
        }
        eprintln("");
    }
    const status = try process.run(argv);
    if (status != 0) throw BuildError.StepFailed;
}

/** Compiles one C file for a target and mode into .helix-cache, once per run. Returns the object's path. */
function compileC(b: *Build, package: string, index: usize, file: string, target: ?string, mode: Mode,
                  flags: readonly string[], includes: readonly string[]): string | Error {
    const object = try fmt.alloc(b.a, `.helix-cache/c/${target ?? "host"}/${modeName(mode)}/${package}/${index}.o`);
    for (const done of b.compiled.items) {
        if (equal(done, object)) return object;
    }
    const dir = try fmt.alloc(b.a, `.helix-cache/c/${target ?? "host"}/${modeName(mode)}/${package}`);
    try fs.makePath(dir);

    let argv = ArrayList<string>.init(b.a);
    try argv.append(b.helix);
    try argv.append("cc");
    if (const t = target) {
        try argv.append("--target");
        try argv.append(t);
    }
    try argv.append("-c");
    try argv.append(file);
    try argv.append("-o");
    try argv.append(object);
    try argv.append(cOptimization(mode));
    if (mode == Mode.Debug) try argv.append("-g");
    for (const dir_path of includes) try argv.append(try fmt.alloc(b.a, `-I${dir_path}`));
    for (const flag of flags) try argv.append(flag);
    try command(b, argv.items);
    try b.compiled.append(object);
    return object;
}

/** `.exe` for Windows, `.wasm` for WASI, nothing elsewhere. */
function executableSuffix(target: ?string): string {
    if (const t = target) {
        if (indexOf(t, "windows") != null) return ".exe";
        if (indexOf(t, "wasi") != null) return ".wasm";
    }
    return "";
}

/** Whether two artifacts' targets are the same (null: the machine's). */
function sameTarget(x: ?string, y: ?string): bool {
    if (const a = x) {
        if (const b = y) return equal(a, b);
        return false;
    }
    return y == null;
}

/** Where artifacts for a target and mode are built, in .helix-cache. */
function cacheDir(b: *Build, target: ?string, mode: Mode): string | Error {
    return try fmt.alloc(b.a, `.helix-cache/bin/${target ?? "host"}/${modeName(mode)}`);
}

/** Compiles an artifact, its C files and what its dependencies bring, unless this run already did. */
function buildArtifact(b: *Build, index: usize): void | Error {
    const art = b.artifacts.items[index];
    if (art.built) return;
    try fs.makePath(try cacheDir(b, art.target, art.mode));

    let argv = ArrayList<string>.init(b.a);
    try argv.append(b.helix);
    try argv.append("build");
    try argv.append(art.root);
    try argv.append("-o");
    try argv.append(art.output);
    try argv.append("--mode");
    try argv.append(modeName(art.mode));
    if (const t = art.target) {
        try argv.append("--target");
        try argv.append(t);
    }
    if (const cpu = art.cpu) {
        try argv.append("--cpu");
        try argv.append(cpu);
    }
    if (art.strip) try argv.append("--strip");
    if (const script = art.linkerScript) {
        try argv.append("--linker-script");
        try argv.append(script);
    }
    try artifactOptions(b, index, art.target, art.mode, &argv);
    try command(b, argv.items);
    b.artifacts.items[index].built = true;
}

/**
 * `--link`, `-l` and `--pkg` for an artifact's own C files (compiled for `target` and `mode`), system libraries and
 * `addOptions` modules (written to .helix-cache/options/).
 */
function artifactOptions(b: *Build, index: usize, target: ?string, mode: Mode, argv: *ArrayList<string>): void | Error {
    const art = b.artifacts.items[index];
    for (const o of art.options.items) {
        const module = b.optionModules.items[o];
        let text = fmt.Builder.init(b.a);
        try text.append(`// Generated by build.hx's addOptions("${module.name}"); rebuilt on every \`helix build\`.\n`);
        for (const line of module.lines.items) try text.append(`${line}\n`);
        try fs.makePath(".helix-cache/options");
        const path = try fmt.alloc(b.a, `.helix-cache/options/${module.name}.hx`);
        try fs.writeFile(path, text.text());
        try argv.append("--pkg");
        try argv.append(try fmt.alloc(b.a, `${module.name}=${path}`));
    }
    const own = try fmt.alloc(b.a, `${art.name}.c`);   // the artifact's own C files, in their own folder
    for (const file, i of art.cFiles.items) {
        try argv.append("--link");
        try argv.append(try compileC(b, own, i, file.path, target, mode, file.flags, art.includeDirs.items));
    }
    for (const lib of art.libraries.items) try argv.append(try fmt.alloc(b.a, `-l${lib}`));
}

/** Performs step `index`, after the steps it depends on. */
function make(b: *Build, index: usize): void | Error {
    if (b.steps.items[index].done) return;
    for (const dep of b.steps.items[index].deps.items) try make(b, dep);
    const step = b.steps.items[index];
    switch (step.kind) {
        case StepKind.Group: {}
        case StepKind.Install: {
            try buildArtifact(b, step.artifact);
            const art = b.artifacts.items[step.artifact];
            const dir = try fmt.alloc(b.a, `helix-out/${step.argv[0]}`);
            try fs.makePath(dir);
            const installed = try fmt.alloc(b.a, `${dir}/${art.name}${executableSuffix(art.target)}`);
            try fs.copyFile(art.output, installed);
            if (b.verbose) eprintln(`installed ${installed}`);
        }
        case StepKind.Run: {
            try buildArtifact(b, step.artifact);
            let argv = ArrayList<string>.init(b.a);
            try argv.append(b.artifacts.items[step.artifact].output);
            for (const arg of b.runArgs) try argv.append(arg);
            const status = try process.run(argv.items);
            if (status != 0) exit(status);   // the program's own status, as `helix run` gives it
        }
        case StepKind.Test: {
            const target = step.test.target ?? b.target;
            const mode = step.test.mode ?? b.mode;
            let argv = ArrayList<string>.init(b.a);
            try argv.append(b.helix);
            try argv.append("test");
            try argv.append(step.test.root);
            try argv.append("--mode");
            try argv.append(modeName(mode));
            if (const t = target) {
                try argv.append("--target");
                try argv.append(t);
            }
            if (const art = step.test.linkWith) try artifactOptions(b, art.index, target, mode, &argv);
            try command(b, argv.items);
        }
        case StepKind.Command: try command(b, step.argv);
    }
    b.steps.items[index].done = true;
}

/** Reads what `helix build` wrote about the project: `bin <tab> - <tab> name <tab> root` lines. */
function readPackages(b: *Build, path: string): void | Error {
    const contents = try fs.readFile(b.a, path);
    for (const line of lines(contents)) {
        let fields = split(line, "\t");
        const kind = fields.next() ?? "";
        void fields.next();
        const name = fields.next() ?? "";
        if (!equal(kind, "bin")) throw BuildError.BadPackageList;
        try b.bins.append(Define { name, value: fields.next() ?? "" });
    }
}

/**
 * What every project gets before its build.hx runs: each `bin` of helix.jsonc built and installed, a `run` step for
 * the first, and a `test` step for src/. The `run` and `test` are defaults that build.hx's own replace.
 */
function addManifest(b: *Build): void | Error {
    let first: ?Artifact = null;
    for (const bin of b.bins.items) {
        const app = try b.addExecutable({ name: bin.name, root: bin.value });
        try b.install(app);
        if (first == null) {
            try b.addRunStep(app);
            try b.defaults.append(b.steps.items.len - 1);
            first = app;
        }
    }
    try b.addTestStep({ root: "src", linkWith: first });
    try b.defaults.append(b.steps.items.len - 1);
}

/** The mode `--mode` names; null when there's none by that name. */
function modeNamed(name: string): ?Mode {
    for (const m of MODES) {
        if (equal(modeName(m), name)) return m;
    }
    return null;
}

/**
 * The build runner's `main`: `<runner> <helix> <packages.txt> [steps] [--target t] [--mode m] [-Dname=value]
 * [--help] [--steps] [-v] [-- args]`.
 * `helix build` starts it; `build` is the function from build.hx.
 */
export function runBuild(init: Init, build: (b: *Build) => void | Error): u8 | Error {
    let arena = ArenaAllocator.init(cAllocator());
    defer arena.deinit();
    const a = arena.allocator();
    if (init.args.len < 2) {
        eprintln("error: the build runner is started by `helix build`");
        return 2;
    }

    let b = Build {
        a, helix: init.args[0], verbose: false, target: null, mode: Mode.Debug, defines: ArrayList<Define>.init(a), declared: ArrayList<Declared>.init(a),
        bins: ArrayList<Define>.init(a), optionModules: ArrayList<OptionsData>.init(a), runArgs: [],
        artifacts: ArrayList<ArtifactData>.init(a),
        steps: ArrayList<StepData>.init(a), compiled: ArrayList<string>.init(a), defaults: ArrayList<usize>.init(a),
    };
    void try b.addStep(StepData {
        name: "install", description: "Build everything `install`ed into helix-out/ (the default)", kind: StepKind.Group,
        artifact: 0, test: TestOptions { root: "" }, argv: [], deps: ArrayList<usize>.init(a), done: false,
    });
    try readPackages(&b, init.args[1]);

    let wanted = ArrayList<string>.init(a);
    let list = false;
    let help = false;
    const args = init.args[2..];
    let at: usize = 0;
    while (at < args.len) {
        const arg = args[at];
        at += 1;
        if (equal(arg, "--")) {
            b.runArgs = args[at..];
            break;
        }
        if ((equal(arg, "--target") || equal(arg, "--mode")) && at == args.len) {
            eprintln(`error: ${arg} needs a value`);
            return 2;
        }
        if (equal(arg, "--target")) {
            b.target = args[at];
            at += 1;
        } else if (equal(arg, "--mode")) {
            if (const m = modeNamed(args[at])) {
                b.mode = m;
            } else {
                eprintln(`error: unknown mode '${args[at]}' (use debug, release-safe, release-fast or release-small)`);
                return 2;
            }
            at += 1;
        } else if (equal(arg, "-v")) {
            b.verbose = true;
        } else if (equal(arg, "--steps")) {
            list = true;
        } else if (equal(arg, "--help") || equal(arg, "-h")) {
            help = true;
        } else if (startsWith(arg, "-D")) {
            const eq = indexOf(arg, "=") ?? arg.len;
            try b.defines.append(Define { name: arg[2..eq], value: eq < arg.len ? arg[eq + 1..] : "true" });
        } else if (startsWith(arg, "-")) {
            eprintln(`error: unknown option '${arg}'`);
            return 2;
        } else {
            try wanted.append(arg);
        }
    }

    try addManifest(&b);
    try build(&b);

    if (help) {
        println("Usage: helix build [steps] [--target t] [--mode m] [-Dname=value] [-v] [-- program args]\n\nSteps:");
        for (const s of b.steps.items) {
            if (s.name.len > 0) println(`  ${s.name}  ${s.description}`);
        }
        println("\nOptions (from build.hx):");
        if (b.declared.items.len == 0) println("  (none)");
        for (const d of b.declared.items) println(`  -D${d.name}=[${d.kind}]  ${d.description}`);
        println("\nGeneral:");
        println("  --target t  what to build for: aarch64-macos, x86_64-linux-gnu, x86_64-windows, ... (default: this machine)");
        println("  --mode m  debug (default), release-safe, release-fast or release-small");
        println("  -v  print each command\n  --steps  list the steps\n  --help  this list");
        return 0;
    }
    if (list) {
        for (const s of b.steps.items) {
            if (s.name.len > 0) println(`  ${s.name}  ${s.description}`);
        }
        return 0;
    }
    for (const d of b.defines.items) {   // a -D that build.hx never asked about is a typo, not a no-op
        let known = false;
        for (const k of b.declared.items) known = known || equal(k.name, d.name);
        if (!known && (equal(d.name, "target") || equal(d.name, "mode"))) {
            eprintln(`error: -D${d.name} is now --${d.name}: \`helix build --${d.name} ${d.value}\``);
            return 2;
        }
        if (!known) {
            eprintln(`error: build.hx has no option -D${d.name}; \`helix build --help\` lists them`);
            return 2;
        }
    }
    if (wanted.items.len == 0) try wanted.append("install");
    for (const name of wanted.items) {
        let found: ?usize = null;
        for (const s, i of b.steps.items) {
            if (equal(s.name, name)) found = i;
        }
        if (const index = found) {
            make(&b, index) catch (e) {
                if (e != BuildError.StepFailed) eprintln(`error: step "${name}" failed: ${@errorName(e)}`);
                return 1;
            };
        } else {
            eprintln(`error: build.hx has no step "${name}"; \`helix build --help\` lists them`);
            return 2;
        }
    }
    return 0;
}
