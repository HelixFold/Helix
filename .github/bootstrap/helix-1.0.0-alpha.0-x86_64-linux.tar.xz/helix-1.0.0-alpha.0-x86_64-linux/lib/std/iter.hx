/**
 * Iterators hand out items one at a time. `for (const x of it)` works on any type with a method
 * `next(this: *Self): ?T`, so a type doesn't need to name this interface to be looped over; `Iterator<T>` is for
 * taking any iterator at runtime: `function sum(it: dyn Iterator<i64>): i64`.
 */

export interface Iterator<T> {
    /** The next item, or null when there are no more. */
    next(this: *Self): ?T;
}
