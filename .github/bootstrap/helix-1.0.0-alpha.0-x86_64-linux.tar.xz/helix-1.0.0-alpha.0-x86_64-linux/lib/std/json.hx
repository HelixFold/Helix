/**
 * JSON, and JSONC (comments and trailing commas, as in tsconfig.json) with `{ comments: true }`.
 *
 *     let arena = ArenaAllocator.init(cAllocator());   // everything the value holds comes from the allocator:
 *     defer arena.deinit();                             // an arena frees it all at once
 *     let problem = JsonProblem { message: "", at: 0 };
 *     const doc = parseJson(arena.allocator(), text, JsonOptions { comments: true }, &problem) catch {
 *         const where = lineCol(text, problem.at);
 *         eprintln(`config.json:${where.line}:${where.col}: ${problem.message}`);
 *         return;
 *     };
 *     const name = doc.get("name")?.text ?? "unnamed";
 *
 * Each value keeps where it is in the text (`start`, `end`), so a tool can change one part of a file and leave
 * the rest - comments, order, spacing - as it was.
 */

import { Allocator, alloc, free } from "./heap";
import { ArrayList } from "./list";
import { Writer } from "./io";

extern "C" function strtod(text: readonly u8[*], end: *?u8[*]): f64;

export enum JsonKind { Null, Bool, Number, String, Array, Object }

export struct JsonValue {
    kind: JsonKind,
    boolean: bool,
    number: f64,
    text: string,           // String: the decoded text
    items: JsonValue[],     // Array: the elements; Object: the values, in order
    keys: string[],         // Object: the names, in order
    start: usize,           // where the value is in the text: [start, end)
    end: usize,

    /** An object's member `key`, or null (also when this isn't an object). */
    get(this: readonly *JsonValue, key: string): ?readonly *JsonValue {
        if (this.kind != JsonKind.Object) return null;
        for (const k, i of this.keys) {
            if (same(k, key)) return &this.items[i];
        }
        return null;
    }

    /** The string, or null when this isn't one. */
    string(this: readonly *JsonValue): ?string {
        if (this.kind != JsonKind.String) return null;
        return this.text;
    }
}

export struct JsonOptions {
    comments: bool = false,     // allow `//` and `/* */` comments and trailing commas
}

/** What went wrong, and where (a byte offset; `lineCol` turns it into a line and column). */
export struct JsonProblem {
    message: string,
    at: usize,
}

export error JsonError { Syntax, TooDeep }

export struct LineCol {
    line: usize,
    col: usize,
}

/** The 1-based line and column of byte `at` in `text`. */
export function lineCol(text: string, at: usize): LineCol {
    let line: usize = 1;
    let col: usize = 1;
    for (const c, i of text) {
        if (i >= at) break;
        if (c == '\n') {
            line++;
            col = 1;
        } else {
            col++;
        }
    }
    return LineCol { line, col };
}

function same(a: string, b: string): bool {
    if (a.len != b.len) return false;
    for (const c, i of a) {
        if (c != b[i]) return false;
    }
    return true;
}

struct Reader {
    text: string,
    pos: usize,
    a: dyn Allocator,
    comments: bool,
    problem: *JsonProblem,
    depth: u32,

    fail(this: *Reader, message: string): JsonError {
        this.problem.message = message;
        this.problem.at = this.pos;
        return JsonError.Syntax;
    }

    peek(this: readonly *Reader): u8 {
        return this.pos < this.text.len ? this.text[this.pos] : 0;
    }

    /** Past whitespace, and comments when they're allowed. */
    skip(this: *Reader): void | JsonError {
        while (this.pos < this.text.len) {
            const c = this.text[this.pos];
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                this.pos++;
                continue;
            }
            if (c != '/' || this.pos + 1 >= this.text.len) return;
            if (!this.comments && (this.text[this.pos + 1] == '/' || this.text[this.pos + 1] == '*')) {
                throw this.fail("JSON has no comments (`{ comments: true }` reads JSONC)");
            }
            const next = this.text[this.pos + 1];
            if (next == '/') {
                while (this.pos < this.text.len && this.text[this.pos] != '\n') this.pos++;
            } else if (next == '*') {
                this.pos += 2;
                while (this.pos + 1 < this.text.len && !(this.text[this.pos] == '*' && this.text[this.pos + 1] == '/')) this.pos++;
                if (this.pos + 1 >= this.text.len) throw this.fail("unterminated comment");
                this.pos += 2;
            } else {
                return;
            }
        }
    }

    word(this: *Reader, w: string): bool {
        if (this.pos + w.len > this.text.len || !same(this.text[this.pos..this.pos + w.len], w)) return false;
        this.pos += w.len;
        return true;
    }

    value(this: *Reader): JsonValue | Error {
        try this.skip();
        let v = JsonValue { kind: JsonKind.Null, boolean: false, number: 0, text: "", items: [], keys: [], start: this.pos, end: this.pos };
        const c = this.peek();
        if (c == '{' || c == '[') {
            this.depth++;
            if (this.depth > 256) {
                this.problem.message = "nested more than 256 deep";
                this.problem.at = this.pos;
                throw JsonError.TooDeep;
            }
            if (c == '{') try this.object(&v);
            else try this.array(&v);
            this.depth--;
        } else if (c == '"') {
            v.kind = JsonKind.String;
            v.text = try this.string();
        } else if (c == '-' || (c >= '0' && c <= '9')) {
            v.kind = JsonKind.Number;
            v.number = try this.numberValue();
        } else if (this.word("true")) {
            v.kind = JsonKind.Bool;
            v.boolean = true;
        } else if (this.word("false")) {
            v.kind = JsonKind.Bool;
        } else if (!this.word("null")) {
            throw this.fail(this.pos >= this.text.len ? "expected a value, found the end" : "expected a value");
        }
        v.end = this.pos;
        return v;
    }

    numberValue(this: *Reader): f64 | Error {
        const start = this.pos;
        if (this.peek() == '-') this.pos++;
        if (this.peek() < '0' || this.peek() > '9') throw this.fail("expected a digit");
        while (this.peek() >= '0' && this.peek() <= '9') this.pos++;
        if (this.peek() == '.') {
            this.pos++;
            if (this.peek() < '0' || this.peek() > '9') throw this.fail("expected a digit after `.`");
            while (this.peek() >= '0' && this.peek() <= '9') this.pos++;
        }
        if (this.peek() == 'e' || this.peek() == 'E') {
            this.pos++;
            if (this.peek() == '+' || this.peek() == '-') this.pos++;
            if (this.peek() < '0' || this.peek() > '9') throw this.fail("expected a digit in the exponent");
            while (this.peek() >= '0' && this.peek() <= '9') this.pos++;
        }
        // strtod wants a NUL after the number
        const len = this.pos - start;
        const copy = try alloc<u8>(this.a, len + 1);
        defer free(this.a, copy);
        for (const i of 0..len) copy[i] = this.text[start + i];
        copy[len] = 0;
        let end: ?u8[*] = null;
        return strtod(copy.ptr, &end);
    }

    hex4(this: *Reader): u32 | JsonError {
        let v: u32 = 0;
        for (const _ of 0..4) {
            const c = this.peek();
            let d: u32 = 0;
            if (c >= '0' && c <= '9') d = (c - '0') as u32;
            else if (c >= 'a' && c <= 'f') d = (c - 'a') as u32 + 10;
            else if (c >= 'A' && c <= 'F') d = (c - 'A') as u32 + 10;
            else throw this.fail("expected 4 hex digits after `\\u`");
            v = v * 16 + d;
            this.pos++;
        }
        return v;
    }

    /** A string, decoded: escapes resolved and `\u` written as UTF-8. */
    string(this: *Reader): string | Error {
        this.pos++;   // the opening quote
        let out = ArrayList<u8>.init(this.a);
        while (true) {
            if (this.pos >= this.text.len) throw this.fail("unterminated string");
            const c = this.text[this.pos];
            if (c == '"') break;
            if (c < 0x20) throw this.fail("a control character in a string must be escaped");
            this.pos++;
            if (c != '\\') {
                try out.append(c);
                continue;
            }
            const e = this.peek();
            this.pos++;
            if (e == '"' || e == '\\' || e == '/') try out.append(e);
            else if (e == 'n') try out.append('\n');
            else if (e == 't') try out.append('\t');
            else if (e == 'r') try out.append('\r');
            else if (e == 'b') try out.append(8);
            else if (e == 'f') try out.append(12);
            else if (e == 'u') {
                let code = try this.hex4();
                if (code >= 0xD800 && code < 0xDC00 && this.word("\\u")) {   // a surrogate pair
                    const low = try this.hex4();
                    code = 0x10000 + ((code - 0xD800) << 10) + (low - 0xDC00);
                }
                if (code < 0x80) {
                    try out.append(@truncate(u8, code));
                } else if (code < 0x800) {
                    try out.append(@truncate(u8, 0xC0 | (code >> 6)));
                    try out.append(@truncate(u8, 0x80 | (code & 0x3F)));
                } else if (code < 0x10000) {
                    try out.append(@truncate(u8, 0xE0 | (code >> 12)));
                    try out.append(@truncate(u8, 0x80 | ((code >> 6) & 0x3F)));
                    try out.append(@truncate(u8, 0x80 | (code & 0x3F)));
                } else {
                    try out.append(@truncate(u8, 0xF0 | (code >> 18)));
                    try out.append(@truncate(u8, 0x80 | ((code >> 12) & 0x3F)));
                    try out.append(@truncate(u8, 0x80 | ((code >> 6) & 0x3F)));
                    try out.append(@truncate(u8, 0x80 | (code & 0x3F)));
                }
            } else {
                this.pos--;
                throw this.fail("unknown escape in a string");
            }
        }
        this.pos++;   // the closing quote
        return out.items;
    }

    /** After an item: a `,` (then true, more may follow) or the closing bracket (false). */
    separator(this: *Reader, close: u8): bool | Error {
        try this.skip();
        if (this.peek() == ',') {
            this.pos++;
            try this.skip();
            if (this.peek() == close) {
                if (!this.comments) throw this.fail("trailing comma");
                return false;
            }
            return true;
        }
        if (this.peek() != close) throw this.fail(close == ']' ? "expected `,` or `]`" : "expected `,` or `}`");
        return false;
    }

    array(this: *Reader, v: *JsonValue): void | Error {
        v.kind = JsonKind.Array;
        this.pos++;
        let items = ArrayList<JsonValue>.init(this.a);
        try this.skip();
        if (this.peek() != ']') {
            while (true) {
                try items.append(try this.value());
                if (!try this.separator(']')) break;
            }
        }
        this.pos++;
        v.items = items.items;
    }

    object(this: *Reader, v: *JsonValue): void | Error {
        v.kind = JsonKind.Object;
        this.pos++;
        let keys = ArrayList<string>.init(this.a);
        let values = ArrayList<JsonValue>.init(this.a);
        try this.skip();
        if (this.peek() != '}') {
            while (true) {
                try this.skip();
                if (this.peek() != '"') throw this.fail("expected a member name in quotes");
                try keys.append(try this.string());
                try this.skip();
                if (this.peek() != ':') throw this.fail("expected `:` after the member name");
                this.pos++;
                try values.append(try this.value());
                if (!try this.separator('}')) break;
            }
        }
        this.pos++;
        v.keys = keys.items;
        v.items = values.items;
    }
}

/**
 * Parses `text`. Everything the value holds comes from `a`; an arena gives it back all at once. On a syntax
 * error, `problem` says what and where.
 */
export function parseJson(a: dyn Allocator, text: string, options: JsonOptions, problem: *JsonProblem): JsonValue | Error {
    let r = Reader { text, pos: 0, a, comments: options.comments, problem, depth: 0 };
    const v = try r.value();
    try r.skip();
    if (r.pos < text.len) throw r.fail("expected the end after the value");
    return v;
}

/** Writes `text` as a JSON string literal: quotes, and escapes where JSON needs them. */
export function writeJsonString(w: dyn Writer, text: string): void | Error {
    const digits = "0123456789abcdef";
    try w.write("\"");
    let start: usize = 0;
    for (const c, i of text) {
        if (c != '"' && c != '\\' && c >= 0x20) continue;
        try w.write(text[start..i]);
        start = i + 1;
        if (c == '"') try w.write("\\\"");
        else if (c == '\\') try w.write("\\\\");
        else if (c == '\n') try w.write("\\n");
        else if (c == '\t') try w.write("\\t");
        else if (c == '\r') try w.write("\\r");
        else {
            const escape: u8[6] = ['\\', 'u', '0', '0', digits[c >> 4], digits[c & 15]];
            try w.write(&escape);
        }
    }
    try w.write(text[start..]);
    try w.write("\"");
}
