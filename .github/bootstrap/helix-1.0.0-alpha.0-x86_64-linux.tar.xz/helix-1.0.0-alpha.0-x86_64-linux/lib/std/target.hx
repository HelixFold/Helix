// What the program is built for (`--target`, or this machine): the compiler writes this module for every build, so
// code can choose per platform while compiling, and only the branch it takes is compiled:
//
//   import { target, Os } from "std/target";
//   if (comptime target.os == Os.Windows) { ... } else { ... }
//
// This file shows its shape; each build gets its own values.

/** The operating system: `macos`, `linux`, `windows`, `wasi`, or `freestanding` (no OS: kernels, firmware). */
export enum Os { Macos, Linux, Windows, Wasi, Freestanding }

/** The processor: `arm64e` is aarch64 with pointer authentication (Apple's); `thumb` a Cortex-M microcontroller. */
export enum Arch { X86_64, Aarch64, Arm64e, Riscv64, Wasm32, Thumb }

export struct Target {
    os: Os,
    arch: Arch,
    pointerBits: u32,   // 64, or 32 on wasm32 and Cortex-M
}

export const target: Target = Target { os: Os.Macos, arch: Arch.Aarch64, pointerBits: 64 };
