/*
 * The test runner, linked into the binaries `helix test` builds. The compiler turns a spec's `describe` and `test`
 * blocks into functions and a table of them in source order; `hx_test_main` walks that table.
 *
 * Every `describe` runs in its own forked process: it sets up its fixtures and runs `beforeAll`, then forks once
 * more for each test inside. So each test starts from a fresh copy of the fixtures, and a panic, crash or timeout
 * only ends that one process. The process that forked a test waits for it and records the result.
 *
 * A test's stdout and stderr go to a file that's printed only if the test fails. Failed `expect`s write their
 * report to descriptor 3. Results are appended to a shared details file, and the counters live in shared memory,
 * so the top process can print the header and the details once every test has run.
 */

#include <errno.h>
#include <fcntl.h>
#include <fnmatch.h>
#include <math.h>
#include <regex.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

typedef uint16_t (*TestFn)(void);

/** One row of the compiler's table (must match `helix.test.entry`). */
typedef struct {
    int32_t kind;
    int32_t mode;
    const char *name;
    const char *message;    // `test.panics`: the expected message
    TestFn fn;              // test: the body; describe: fixtures and `beforeAll`; end: `afterAll`
    TestFn before;          // describe: its `beforeEach` hooks
    TestFn after;           // describe: its `afterEach` hooks
    const char *location;   // "file:line:col"
    int64_t timeout_ms;     // test: `{ timeout: ms }`, 0 = the run's default
} Entry;

enum { ENTRY_DESCRIBE, ENTRY_END, ENTRY_TEST };
enum { MODE_PLAIN, MODE_SKIP, MODE_ONLY, MODE_TODO, MODE_FAILING, MODE_PANICS };

/** Counters every process of the run adds to. */
typedef struct {
    int64_t passed, failed, panicked, skipped, todo;
    bool stop;              // `--bail` after a failure
} Shared;

#define MAX_DEPTH 64

static struct {
    const Entry *entries;
    int64_t count;
    const char *(*error_name)(uint16_t);
    void (*begin)(void);
    uint64_t (*end)(void);
    uint16_t require_code;

    bool verbose, bail, color;
    bool json;              // `--json`: one JSON object per line, for editors (docs/design/ide.md)
    bool teamcity;          // `--teamcity`: TeamCity service messages, which JetBrains IDEs' test trees read
    int64_t timeout_ms;
    bool has_filter;
    regex_t filter;
    const char *label;

    Shared *shared;
    int details;            // the shared details file
    bool *runs;             // per entry: a test that runs, or a describe with a test that runs
    bool *marked;           // per test: skipped by `.skip` or `.todo` (its own or a describe's), not just filtered out
    int path[MAX_DEPTH];    // the describes around the current entry
    int depth;
} t;

static bool failed;         // the current test: an `expect` failed or something else went wrong

/* ---- called from generated code ---- */

void hx_test_fail(void) {
    failed = true;
    write(3, "\n", 1);   // separates one failed `expect`'s report from the next
}

/** `toBeCloseTo`: |a - b| < 10^-digits / 2, as in Jest. */
bool hx_test_close_to(double a, double b, int32_t digits) {
    if (isinf(a) && isinf(b)) return a == b;
    return fabs(a - b) < pow(10.0, -digits) / 2;
}

/** `toStartWith`, `toEndWith`, `toInclude` and `toMatch` (a glob) on two Helix strings. */
bool hx_test_text(int32_t kind, const char *text, int64_t text_len, const char *part, int64_t part_len) {
    switch (kind) {
    case 0: return part_len <= text_len && memcmp(text, part, (size_t)part_len) == 0;
    case 1: return part_len <= text_len && memcmp(text + text_len - part_len, part, (size_t)part_len) == 0;
    case 2:
        if (part_len == 0) return true;
        for (int64_t i = 0; i + part_len <= text_len; i++) {
            if (memcmp(text + i, part, (size_t)part_len) == 0) return true;
        }
        return false;
    default: {
        char *a = strndup(text, (size_t)text_len), *b = strndup(part, (size_t)part_len);
        bool match = a && b && fnmatch(b, a, 0) == 0;
        free(a);
        free(b);
        return match;
    }
    }
}

/* ---- output ---- */

#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define DIM "\033[2m"
#define BOLD "\033[1m"
#define RESET "\033[0m"

static const char *paint(const char *code) {
    return t.color ? code : "";
}

/** Appends to the details file in one write, so records from different processes never mix. */
static void detail(const char *text, size_t len) {
    while (len > 0) {
        ssize_t n = write(t.details, text, len);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) return;
        text += n;
        len -= (size_t)n;
    }
}

typedef struct {
    char *data;
    size_t len, cap;
} Buf;

static void buf_add(Buf *b, const char *text, size_t len) {
    if (b->len + len + 1 > b->cap) {
        b->cap = (b->len + len + 1) * 2;
        b->data = realloc(b->data, b->cap);
        if (!b->data) abort();
    }
    memcpy(b->data + b->len, text, len);
    b->len += len;
    b->data[b->len] = '\0';
}

static void buf_printf(Buf *b, const char *fmt, ...) __attribute__((format(printf, 2, 3)));

static void buf_printf(Buf *b, const char *fmt, ...) {
    char small[1024];
    va_list args;
    va_start(args, fmt);
    int n = vsnprintf(small, sizeof small, fmt, args);
    va_end(args);
    if (n < 0) return;
    if ((size_t)n < sizeof small) {
        buf_add(b, small, (size_t)n);
        return;
    }
    char *big = malloc((size_t)n + 1);
    va_start(args, fmt);
    vsnprintf(big, (size_t)n + 1, fmt, args);
    va_end(args);
    buf_add(b, big, (size_t)n);
    free(big);
}

/** Adds `text` with every line indented, dropping trailing blank lines. */
static void buf_indented(Buf *b, const char *text, size_t len, const char *indent) {
    while (len > 0 && (text[len - 1] == '\n' || text[len - 1] == ' ')) len--;
    size_t start = 0;
    while (start < len) {
        size_t end = start;
        while (end < len && text[end] != '\n') end++;
        if (end > start) buf_add(b, indent, strlen(indent));
        buf_add(b, text + start, end - start);
        buf_add(b, "\n", 1);
        start = end + 1;
    }
}

/** The whole contents of an open file, from the start. */
static char *slurp(int fd, size_t *len) {
    Buf b = { 0 };
    buf_add(&b, "", 0);
    lseek(fd, 0, SEEK_SET);
    char chunk[4096];
    ssize_t n;
    while ((n = read(fd, chunk, sizeof chunk)) > 0 || (n < 0 && errno == EINTR)) {
        if (n > 0) buf_add(&b, chunk, (size_t)n);
    }
    *len = b.len;
    return b.data;
}

/** "Outer › inner › should ..." for entry `index`, with the describes on the path. */
static void full_name(Buf *b, int index) {
    for (int i = 0; i < t.depth; i++) buf_printf(b, "%s › ", t.entries[t.path[i]].name);
    buf_add(b, t.entries[index].name, strlen(t.entries[index].name));
}

/* ---- --json: one event per line ---- */

/** `text` as a JSON string, quotes included. */
static void buf_json(Buf *b, const char *text, size_t len) {
    buf_add(b, "\"", 1);
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)text[i];
        if (c == '"' || c == '\\') {
            buf_add(b, "\\", 1);
            buf_add(b, (const char *)&text[i], 1);
        } else if (c == '\n') {
            buf_add(b, "\\n", 2);
        } else if (c == '\t') {
            buf_add(b, "\\t", 2);
        } else if (c < 0x20) {
            buf_printf(b, "\\u%04x", c);
        } else {
            buf_add(b, (const char *)&text[i], 1);
        }
    }
    buf_add(b, "\"", 1);
}

/** `["outer", "inner", "name"]`: the describes on the path, then entry `index` (none when it's -1). */
static void json_name(Buf *b, int index) {
    buf_add(b, "[", 1);
    for (int i = 0; i < t.depth; i++) {
        if (i) buf_add(b, ",", 1);
        const char *n = t.entries[t.path[i]].name;
        buf_json(b, n, strlen(n));
    }
    if (index >= 0) {
        if (t.depth) buf_add(b, ",", 1);
        buf_json(b, t.entries[index].name, strlen(t.entries[index].name));
    }
    buf_add(b, "]", 1);
}

/** `,"location":{...}` for the first `at file.hx:line:col` line of a failure report, if there is one. */
static void json_location(Buf *b, const char *text, size_t len) {
    size_t start = 0;
    while (start < len) {
        size_t end = start;
        while (end < len && text[end] != '\n') end++;
        size_t i = start;
        while (i < end && text[i] == ' ') i++;
        if (end - i > 3 && memcmp(text + i, "at ", 3) == 0) {
            // file:line:col, from the end: the file name may hold colons
            size_t colon2 = end, colon1;
            while (colon2 > i && text[colon2 - 1] != ':') colon2--;
            colon1 = colon2 > i + 1 ? colon2 - 1 : i;
            while (colon1 > i && text[colon1 - 1] != ':') colon1--;
            if (colon1 > i + 3 && colon2 > colon1) {
                long line = strtol(text + colon1, NULL, 10), col = strtol(text + colon2, NULL, 10);
                if (line > 0 && col > 0) {
                    buf_printf(b, ",\"location\":{\"file\":");
                    buf_json(b, text + i + 3, colon1 - 1 - (i + 3));
                    buf_printf(b, ",\"line\":%ld,\"column\":%ld}", line, col);
                    return;
                }
            }
        }
        start = end + 1;
    }
}

/* ---- --teamcity ---- */

/** `text` as a TeamCity value: `|`, `'`, `[`, `]` and line breaks escaped with `|`. */
static void tc_value(Buf *b, const char *text, size_t len) {
    for (size_t i = 0; i < len; i++) {
        char c = text[i];
        if (c == '|' || c == '\'' || c == '[' || c == ']') {
            buf_add(b, "|", 1);
            buf_add(b, &text[i], 1);
        } else if (c == '\n') {
            buf_add(b, "|n", 2);
        } else if (c == '\r') {
            buf_add(b, "|r", 2);
        } else {
            buf_add(b, &text[i], 1);
        }
    }
}

static void tc_attr(Buf *b, const char *name, const char *value, size_t len) {
    buf_printf(b, " %s='", name);
    tc_value(b, value, len);
    buf_add(b, "'", 1);
}

/*
 * A test's messages go to the details file as one record: the describes around it (separated by \x1f), \x1e, then
 * its messages (separated by \x1d). The parent turns the records into suites when it prints them, since describes run
 * in processes of their own.
 */
static void tc_event(int index, const char *status, double ms, const char *message, size_t message_len) {
    Buf b = { 0 };
    for (int i = 0; i < t.depth; i++) {
        const char *n = t.entries[t.path[i]].name;
        if (i) buf_add(&b, "\x1f", 1);
        buf_add(&b, n, strlen(n));
    }
    buf_add(&b, "\x1e", 1);
    const char *name = index >= 0 ? t.entries[index].name : "(the describe itself)";
    size_t name_len = strlen(name);
    buf_add(&b, "##teamcity[testStarted", 22);
    tc_attr(&b, "name", name, name_len);
    buf_add(&b, "]\x1d", 2);
    if (strcmp(status, "skipped") == 0 || strcmp(status, "todo") == 0) {
        buf_add(&b, "##teamcity[testIgnored", 22);
        tc_attr(&b, "name", name, name_len);
        tc_attr(&b, "message", status, strlen(status));
        buf_add(&b, "]\x1d", 2);
    } else if (strcmp(status, "passed") != 0) {
        size_t first = 0;
        while (first < message_len && message[first] != '\n') first++;
        buf_add(&b, "##teamcity[testFailed", 21);
        tc_attr(&b, "name", name, name_len);
        tc_attr(&b, "message", message, first);
        tc_attr(&b, "details", message, message_len);
        buf_add(&b, "]\x1d", 2);
    }
    buf_add(&b, "##teamcity[testFinished", 23);
    tc_attr(&b, "name", name, name_len);
    if (ms >= 0) buf_printf(&b, " duration='%lld'", (long long)ms);
    buf_add(&b, "]\n", 2);
    detail(b.data, b.len);
    free(b.data);
}

static void tc_suite(const char *what, const char *name, size_t len) {
    Buf b = { 0 };
    buf_printf(&b, "##teamcity[%s", what);
    tc_attr(&b, "name", name, len);
    buf_add(&b, "]\n", 2);
    fwrite(b.data, 1, b.len, stdout);
    free(b.data);
}

/** Prints the records of `tc_event`, inside a suite for the file and one for each describe. */
static void tc_print(const char *records, size_t len) {
    tc_suite("testSuiteStarted", t.label, strlen(t.label));
    const char *open[MAX_DEPTH];
    size_t open_len[MAX_DEPTH];
    int depth = 0;
    size_t start = 0;
    while (start < len) {
        size_t end = start;
        while (end < len && records[end] != '\n') end++;
        const char *sep = memchr(records + start, '\x1e', end - start);
        if (sep) {
            // the describes of this record: close those it isn't in, open the new ones
            const char *names[MAX_DEPTH];
            size_t lens[MAX_DEPTH];
            int n = 0;
            const char *p = records + start;
            while (p < sep && n < MAX_DEPTH) {
                const char *q = memchr(p, '\x1f', (size_t)(sep - p));
                if (!q) q = sep;
                names[n] = p;
                lens[n++] = (size_t)(q - p);
                p = q + 1;
            }
            int same = 0;
            while (same < depth && same < n && open_len[same] == lens[same] && memcmp(open[same], names[same], lens[same]) == 0) same++;
            while (depth > same) {
                depth--;
                tc_suite("testSuiteFinished", open[depth], open_len[depth]);
            }
            while (depth < n) {
                open[depth] = names[depth];
                open_len[depth] = lens[depth];
                tc_suite("testSuiteStarted", names[depth], lens[depth]);
                depth++;
            }
            for (const char *m = sep + 1; m < records + end; m++) fputc(*m == '\x1d' ? '\n' : *m, stdout);
            fputc('\n', stdout);
        }
        start = end + 1;
    }
    while (depth > 0) {
        depth--;
        tc_suite("testSuiteFinished", open[depth], open_len[depth]);
    }
    tc_suite("testSuiteFinished", t.label, strlen(t.label));
}

/** One event line in the details file: a test's or a describe's outcome. `ms` < 0 leaves the time out. */
static void json_event(const char *event, int index, const char *status, double ms, const char *message, size_t message_len) {
    if (t.teamcity) {
        tc_event(index, status, ms, message, message_len);
        return;
    }
    Buf b = { 0 };
    buf_printf(&b, "{\"event\":\"%s\",\"file\":", event);
    buf_json(&b, t.label, strlen(t.label));
    buf_add(&b, ",\"name\":", 8);
    json_name(&b, index);
    buf_printf(&b, ",\"status\":\"%s\"", status);
    if (ms >= 0) buf_printf(&b, ",\"ms\":%.3f", ms);
    if (message_len) {
        buf_add(&b, ",\"message\":", 11);
        buf_json(&b, message, message_len);
        json_location(&b, message, message_len);
    }
    buf_add(&b, "}\n", 2);
    detail(b.data, b.len);
    free(b.data);
}

/** A temporary file, already unlinked; it disappears when the last process closes it. */
static int temp_file(void) {
    const char *dir = getenv("TMPDIR");
    char path[1024];
    snprintf(path, sizeof path, "%s/helix-test-XXXXXX", dir && *dir ? dir : "/tmp");
    int fd = mkstemp(path);
    if (fd < 0) {
        perror("helix test: cannot create a temporary file");
        exit(2);
    }
    unlink(path);
    int high = fcntl(fd, F_DUPFD, 10);   // clear of 0-3, which every test process redirects
    if (high >= 0) {
        close(fd);
        fd = high;
    }
    return fd;
}

static double now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1e6;
}

/* ---- selection ---- */

/** The index of the END that closes the describe at `index`. */
static int64_t end_of(int64_t index) {
    int depth = 0;
    for (int64_t i = index; i < t.count; i++) {
        if (t.entries[i].kind == ENTRY_DESCRIBE) depth++;
        else if (t.entries[i].kind == ENTRY_END && --depth == 0) return i;
    }
    return t.count - 1;
}

/**
 * Decides which tests run: not skipped (itself or a describe around it), inside or marked `.only` when any `.only`
 * exists, and matching `--filter`. A describe runs when any test inside it does.
 */
static void hx_select_tests(void) {
    bool any_only = false;
    for (int64_t i = 0; i < t.count; i++) any_only |= t.entries[i].mode == MODE_ONLY;

    int stack[MAX_DEPTH];
    int depth = 0;
    for (int64_t i = 0; i < t.count; i++) {
        const Entry *e = &t.entries[i];
        if (e->kind == ENTRY_DESCRIBE) {
            if (depth < MAX_DEPTH) stack[depth++] = (int)i;
            continue;
        }
        if (e->kind == ENTRY_END) {
            depth--;
            continue;
        }
        bool skipped = e->mode == MODE_SKIP || e->mode == MODE_TODO;
        bool only = e->mode == MODE_ONLY;
        Buf name = { 0 };
        buf_add(&name, "", 0);
        for (int d = 0; d < depth; d++) {
            const Entry *outer = &t.entries[stack[d]];
            skipped |= outer->mode == MODE_SKIP;
            only |= outer->mode == MODE_ONLY;
            buf_printf(&name, "%s ", outer->name);
        }
        buf_add(&name, e->name, strlen(e->name));
        bool matches = !t.has_filter || regexec(&t.filter, name.data, 0, NULL, 0) == 0;
        free(name.data);
        t.runs[i] = !skipped && (!any_only || only) && matches;
        t.marked[i] = skipped;
        if (t.runs[i]) {
            for (int d = 0; d < depth; d++) t.runs[stack[d]] = true;
        }
    }
}

/** Counts the tests of a describe that are not run, as skipped or todo, and lists them with --verbose. */
static void hx_report_not_run(int64_t from, int64_t to) {
    int saved = t.depth;
    for (int64_t i = from; i <= to; i++) {
        const Entry *e = &t.entries[i];
        if (e->kind == ENTRY_DESCRIBE && t.depth < MAX_DEPTH) t.path[t.depth++] = (int)i;
        if (e->kind == ENTRY_END && t.depth > saved) t.depth--;
        if (e->kind != ENTRY_TEST || t.runs[i]) continue;
        bool todo = e->mode == MODE_TODO;
        if (todo) t.shared->todo++;
        else t.shared->skipped++;
        if (t.json && t.marked[i]) json_event("test", (int)i, todo ? "todo" : "skipped", -1, NULL, 0);
        if (!t.verbose || t.json) continue;
        Buf b = { 0 };
        buf_printf(&b, "  %s%s%s ", paint(YELLOW), todo ? "✎ todo" : "○ skip", paint(RESET));
        full_name(&b, (int)i);
        buf_add(&b, "\n", 1);
        detail(b.data, b.len);
        free(b.data);
    }
    t.depth = saved;
}

/* ---- running ---- */

static void hx_run_range(int64_t from, int64_t to);

/** Notes an error from a hook or body in the test's report. */
static void hx_report_error(const char *what, uint16_t code, const char *location) {
    dprintf(3, "%s%serror: %s\n\nat %s\n\n", what, *what ? " failed with " : "", t.error_name(code), location);
    failed = true;
}

/** Runs one test inside its own process; never returns. */
static void hx_test_child(int64_t index, int out, int report) {
    dup2(out, 1);
    dup2(out, 2);
    dup2(report, 3);
    close(out);
    close(report);
    const Entry *e = &t.entries[index];
    int64_t timeout = e->timeout_ms ? e->timeout_ms : t.timeout_ms;
    if (timeout > 0) {
        struct itimerval timer = { .it_value = { .tv_sec = timeout / 1000, .tv_usec = (timeout % 1000) * 1000 } };
        setitimer(ITIMER_REAL, &timer, NULL);
    }
    failed = false;
    t.begin();

    int ready = 0;   // describes whose `beforeEach` ran
    bool ok = true;
    for (; ready < t.depth && ok; ready++) {
        const Entry *d = &t.entries[t.path[ready]];
        uint16_t code = d->before ? d->before() : 0;
        if (code) {
            char what[512];
            snprintf(what, sizeof what, "beforeEach in \"%s\"", d->name);
            hx_report_error(what, code, d->location);
            ok = false;
        }
    }
    if (ok) {
        uint16_t code = e->fn();
        if (code && code != t.require_code) hx_report_error("", code, e->location);
    }
    while (ready-- > 0) {
        const Entry *d = &t.entries[t.path[ready]];
        uint16_t code = d->after ? d->after() : 0;
        if (code) {
            char what[512];
            snprintf(what, sizeof what, "afterEach in \"%s\"", d->name);
            hx_report_error(what, code, d->location);
        }
    }
    uint64_t leaks = t.end();
    if (leaks) {
        dprintf(3, "testing.allocator: %llu allocation%s never freed (sizes in the output below)\n\n",
                (unsigned long long)leaks, leaks == 1 ? " was" : "s were");
        failed = true;
    }
    fflush(stdout);
    fflush(stderr);
    _exit(failed ? 1 : 0);
}

/** The line of the captured output that starts with "panic: ", or NULL. */
static const char *panic_line(const char *output, size_t *len) {
    for (const char *line = output; line && *line;) {
        const char *end = strchr(line, '\n');
        size_t n = end ? (size_t)(end - line) : strlen(line);
        if (n >= 7 && memcmp(line, "panic: ", 7) == 0) {
            *len = n;
            return line;
        }
        line = end ? end + 1 : NULL;
    }
    return NULL;
}

static void hx_run_test(int64_t index) {
    const Entry *e = &t.entries[index];
    int out = temp_file(), report = temp_file();
    fflush(NULL);
    double start = now_ms();
    pid_t pid = fork();
    if (pid < 0) {
        perror("helix test: fork");
        exit(2);
    }
    if (pid == 0) hx_test_child(index, out, report);

    int status;
    while (waitpid(pid, &status, 0) < 0 && errno == EINTR) {}
    double ms = now_ms() - start;

    size_t output_len, report_len;
    char *output = slurp(out, &output_len);
    char *text = slurp(report, &report_len);
    close(out);
    close(report);

    // what happened
    bool exited = WIFEXITED(status);
    bool passed = exited && WEXITSTATUS(status) == 0;
    bool panicked = WIFSIGNALED(status) && WTERMSIG(status) == SIGABRT && panic_line(output, &(size_t){ 0 });
    bool timed_out = WIFSIGNALED(status) && WTERMSIG(status) == SIGALRM;
    Buf why = { 0 };
    buf_add(&why, "", 0);
    if (WIFSIGNALED(status) && !panicked && !timed_out) {
        buf_printf(&why, "the test crashed: %s\n", strsignal(WTERMSIG(status)));
    } else if (timed_out) {
        buf_printf(&why, "timed out after %lld ms\n", (long long)(e->timeout_ms ? e->timeout_ms : t.timeout_ms));
    }

    // what was wanted
    bool ok = passed;
    if (e->mode == MODE_FAILING) {
        ok = !passed && !timed_out;
        if (!ok && passed) buf_printf(&why, "this test is marked `.failing`, but it passed; remove `.failing`\n");
    } else if (e->mode == MODE_PANICS) {
        size_t line_len = 0;
        const char *line = panicked ? panic_line(output, &line_len) : NULL;
        ok = line && memmem(line, line_len, e->message, strlen(e->message));
        if (!ok && line) buf_printf(&why, "expected a panic with \"%s\", but got: %.*s\n", e->message, (int)line_len, line);
        else if (!ok && !panicked) buf_printf(&why, "expected a panic with \"%s\", but the test %s\n", e->message,
                                              passed ? "finished without one" : "failed instead");
    }

    if (t.json) {
        if (ok) {
            t.shared->passed++;
            json_event("test", (int)index, "passed", ms, NULL, 0);
        } else {
            if (panicked && e->mode != MODE_PANICS) t.shared->panicked++;
            else t.shared->failed++;
            Buf m = { 0 };
            buf_add(&m, why.data, why.len);
            if (why.len && report_len) buf_add(&m, "\n", 1);
            buf_add(&m, text, report_len);
            if (output_len) buf_printf(&m, "%soutput:\n%.*s", m.len ? "\n" : "", (int)output_len, output);
            json_event("test", (int)index, panicked && e->mode != MODE_PANICS ? "panicked" : "failed", ms, m.data, m.len);
            free(m.data);
            if (t.bail) t.shared->stop = true;
        }
        free(why.data);
        free(output);
        free(text);
        return;
    }

    Buf b = { 0 };
    buf_add(&b, "", 0);
    char time[32];
    snprintf(time, sizeof time, ms >= 1 ? "%.0f ms" : "%.1f ms", ms);
    if (ok) {
        t.shared->passed++;
        if (t.verbose) {
            buf_printf(&b, "  %s✓%s ", paint(GREEN), paint(RESET));
            full_name(&b, (int)index);
            buf_printf(&b, " %s(%s)%s\n", paint(DIM), time, paint(RESET));
        }
    } else {
        if (panicked && e->mode != MODE_PANICS) t.shared->panicked++;
        else t.shared->failed++;
        buf_printf(&b, "\n  %s✗ ", paint(RED));
        full_name(&b, (int)index);
        buf_printf(&b, "%s %s(%s)%s\n", paint(RESET), paint(DIM), time, paint(RESET));
        buf_indented(&b, why.data, why.len, "    ");
        if (why.len && report_len) buf_add(&b, "\n", 1);
        buf_indented(&b, text, report_len, "    ");
        if (output_len) {
            if (!panicked || report_len || why.len) buf_printf(&b, "\n    %soutput:%s\n", paint(DIM), paint(RESET));
            buf_indented(&b, output, output_len, panicked && !report_len && !why.len ? "    " : "      ");
        }
        if (t.verbose) buf_add(&b, "\n", 1);
        if (t.bail) t.shared->stop = true;
    }
    detail(b.data, b.len);
    free(b.data);
    free(why.data);
    free(output);
    free(text);
}

/** Marks every running test of a describe that never reported as failed, with the reason. */
static void hx_fail_unreported(int64_t from, int64_t to, int64_t reported, const char *reason, const char *output, size_t output_len) {
    int64_t total = 0;
    for (int64_t i = from; i <= to; i++) total += t.entries[i].kind == ENTRY_TEST && t.runs[i];
    int64_t missing = total - reported;
    if (missing <= 0) return;
    t.shared->failed += missing;
    if (t.json) {
        Buf m = { 0 };
        buf_printf(&m, "%s; %lld test%s didn't run", reason, (long long)missing, missing == 1 ? "" : "s");
        if (output_len) buf_printf(&m, "\noutput:\n%.*s", (int)output_len, output);
        json_event("describe", -1, "failed", -1, m.data, m.len);
        free(m.data);
        if (t.bail) t.shared->stop = true;
        return;
    }
    Buf b = { 0 };
    buf_printf(&b, "\n  %s✗ ", paint(RED));
    for (int i = 0; i < t.depth; i++) buf_printf(&b, "%s%s", t.entries[t.path[i]].name, i + 1 < t.depth ? " › " : "");
    buf_printf(&b, "%s\n", paint(RESET));
    buf_printf(&b, "    %s; %lld test%s didn't run\n", reason, (long long)missing, missing == 1 ? "" : "s");
    if (output_len) {
        buf_printf(&b, "\n    %soutput:%s\n", paint(DIM), paint(RESET));
        buf_indented(&b, output, output_len, "      ");
    }
    detail(b.data, b.len);
    free(b.data);
    if (t.bail) t.shared->stop = true;
}

static int64_t hx_tests_reported(void) {
    return t.shared->passed + t.shared->failed + t.shared->panicked;
}

/** A describe in its own process: fixtures and `beforeAll`, the tests inside, then `afterAll`. */
static void hx_run_describe(int64_t index, int64_t end) {
    const Entry *e = &t.entries[index];
    int out = temp_file(), report = temp_file();
    int64_t before = hx_tests_reported();
    fflush(NULL);
    pid_t pid = fork();
    if (pid < 0) {
        perror("helix test: fork");
        exit(2);
    }
    if (pid == 0) {
        dup2(out, 1);
        dup2(out, 2);
        dup2(report, 3);
        if (t.depth < MAX_DEPTH) t.path[t.depth++] = (int)index;
        uint16_t code = e->fn ? e->fn() : 0;
        if (code) {
            char reason[512];
            snprintf(reason, sizeof reason, "beforeAll or a fixture failed with error: %s", t.error_name(code));
            fflush(stdout);
            size_t len;
            char *output = slurp(out, &len);
            hx_fail_unreported(index, end, hx_tests_reported() - before, reason, output, len);
            _exit(0);
        }
        hx_run_range(index + 1, end);
        code = t.entries[end].fn ? t.entries[end].fn() : 0;
        if (code) {
            Buf b = { 0 };
            if (t.json) {
                buf_printf(&b, "afterAll failed with error: %s", t.error_name(code));
                json_event("describe", -1, "failed", -1, b.data, b.len);
            } else {
                buf_printf(&b, "\n  %s✗ %s%s\n    afterAll failed with error: %s\n", paint(RED), e->name, paint(RESET), t.error_name(code));
                detail(b.data, b.len);
            }
            free(b.data);
            t.shared->failed++;
        }
        fflush(NULL);
        _exit(0);
    }

    int status;
    while (waitpid(pid, &status, 0) < 0 && errno == EINTR) {}
    if (!WIFEXITED(status)) {
        size_t len;
        char *output = slurp(out, &len);
        char reason[256];
        snprintf(reason, sizeof reason, "the block %s outside its tests: %s",
                 WTERMSIG(status) == SIGABRT ? "panicked" : "crashed", strsignal(WTERMSIG(status)));
        if (t.depth < MAX_DEPTH) t.path[t.depth++] = (int)index;
        hx_fail_unreported(index, end, hx_tests_reported() - before, reason, output, len);
        t.depth--;
        free(output);
    }
    close(out);
    close(report);
}

static void hx_run_range(int64_t from, int64_t to) {
    for (int64_t i = from; i < to && !t.shared->stop; i++) {
        const Entry *e = &t.entries[i];
        if (e->kind == ENTRY_TEST) {
            if (t.runs[i]) hx_run_test(i);
            else hx_report_not_run(i, i);
        } else if (e->kind == ENTRY_DESCRIBE) {
            int64_t end = end_of(i);
            if (t.runs[i]) hx_run_describe(i, end);
            else hx_report_not_run(i, end);
            i = end;
        }
    }
}

/* ---- main ---- */

static void usage(void) {
    fputs("usage: <test binary> [-f regex] [-b] [-v] [-t ms] [--name label] [--summary file] [--color|--no-color] [--json|--teamcity]\n", stderr);
    exit(2);
}

int hx_test_main(int argc, char **argv, const Entry *entries, int64_t count, const char *(*error_name)(uint16_t),
                 void (*begin)(void), uint64_t (*end)(void), int32_t require_code) {
    t.entries = entries;
    t.count = count;
    t.error_name = error_name;
    t.begin = begin;
    t.end = end;
    t.require_code = (uint16_t)require_code;
    t.timeout_ms = 5000;
    t.label = argv[0];
    t.color = isatty(1) && !(getenv("NO_COLOR") && *getenv("NO_COLOR"));
    const char *summary = NULL;
    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];
        bool has_value = i + 1 < argc;
        if (strcmp(arg, "-v") == 0) t.verbose = true;
        else if (strcmp(arg, "--json") == 0) t.json = true;
        else if (strcmp(arg, "--teamcity") == 0) t.json = t.teamcity = true;
        else if (strcmp(arg, "-b") == 0) t.bail = true;
        else if (strcmp(arg, "--color") == 0) t.color = true;
        else if (strcmp(arg, "--no-color") == 0) t.color = false;
        else if (strcmp(arg, "-t") == 0 && has_value) t.timeout_ms = strtoll(argv[++i], NULL, 10);
        else if (strcmp(arg, "--name") == 0 && has_value) t.label = argv[++i];
        else if (strcmp(arg, "--summary") == 0 && has_value) summary = argv[++i];
        else if (strcmp(arg, "-f") == 0 && has_value) {
            if (regcomp(&t.filter, argv[++i], REG_EXTENDED | REG_NOSUB) != 0) {
                fprintf(stderr, "error: invalid filter regex '%s'\n", argv[i]);
                return 2;
            }
            t.has_filter = true;
        } else {
            usage();
        }
    }

    t.shared = mmap(NULL, sizeof(Shared), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (t.shared == MAP_FAILED) {
        perror("helix test: mmap");
        return 2;
    }
    memset(t.shared, 0, sizeof(Shared));
    t.details = temp_file();
    t.runs = calloc((size_t)count + 1, sizeof(bool));
    t.marked = calloc((size_t)count + 1, sizeof(bool));
    hx_select_tests();

    double start = now_ms();
    hx_run_range(0, count);
    double ms = now_ms() - start;

    Shared s = *t.shared;
    int64_t total = 0;
    for (int64_t i = 0; i < count; i++) total += entries[i].kind == ENTRY_TEST;
    bool ok = s.failed == 0 && s.panicked == 0;
    if (t.teamcity) {
        size_t len;
        char *details = slurp(t.details, &len);
        tc_print(details, len);
        free(details);
    } else if (t.json) {   // the events, then the file's own
        size_t len;
        char *details = slurp(t.details, &len);
        fwrite(details, 1, len, stdout);
        free(details);
        Buf b = { 0 };
        buf_add(&b, "{\"event\":\"file\",\"file\":", 23);
        buf_json(&b, t.label, strlen(t.label));
        buf_printf(&b, ",\"status\":\"%s\",\"tests\":%lld,\"passed\":%lld,\"failed\":%lld,\"panicked\":%lld,"
                   "\"skipped\":%lld,\"todo\":%lld,\"ms\":%.3f}\n", ok ? "passed" : "failed", (long long)total,
                   (long long)s.passed, (long long)s.failed, (long long)s.panicked, (long long)s.skipped, (long long)s.todo, ms);
        fwrite(b.data, 1, b.len, stdout);
        free(b.data);
    } else {
        printf(" %s%s%s%s %s (%lld test%s", paint(BOLD), paint(ok ? GREEN : RED), ok ? "PASS" : "FAIL", paint(RESET), t.label,
               (long long)total, total == 1 ? "" : "s");
        if (s.failed) printf(", %lld failed", (long long)s.failed);
        if (s.panicked) printf(", %lld panicked", (long long)s.panicked);
        printf(", %.1f ms)\n", ms);
        size_t len;
        char *details = slurp(t.details, &len);
        fwrite(details, 1, len, stdout);
        if (len && (!ok || t.verbose)) fputc('\n', stdout);
        free(details);
    }
    fflush(stdout);

    if (summary) {
        FILE *f = fopen(summary, "w");
        if (f) {
            fprintf(f, "%lld %lld %lld %lld %lld\n", (long long)s.passed, (long long)s.failed, (long long)s.panicked,
                    (long long)s.skipped, (long long)s.todo);
            fclose(f);
        }
    }
    return ok ? 0 : 1;
}
