/**
 * SHA-256 (FIPS 180-4).
 *
 *     const digest = sha256(bytes);                // u8[32]
 *     let h = Sha256.init();                       // or piece by piece
 *     h.update(part1);
 *     h.update(part2);
 *     const hexDigits = toHex(h.finish());         // u8[64]: lowercase hex
 */

const K: u32[64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

const INITIAL: u32[8] = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];

function rotr(x: u32, n: u32): u32 {
    return (x >> n) | (x << (32 - n));
}

export struct Sha256 {
    state: u32[8],
    length: u64,        // bytes fed so far
    block: u8[64],
    used: usize,        // bytes waiting in `block`

    init(): Sha256 {
        return Sha256 { state: INITIAL, length: 0, block: undefined, used: 0 };
    }

    /** Feeds more bytes in. */
    update(this: *Sha256, bytes: readonly u8[]): void {
        this.length +%= bytes.len as u64;
        let at: usize = 0;
        while (at < bytes.len) {
            const take = 64 - this.used < bytes.len - at ? 64 - this.used : bytes.len - at;
            for (const i of 0..take) this.block[this.used + i] = bytes[at + i];
            this.used += take;
            at += take;
            if (this.used == 64) {
                this.compress();
                this.used = 0;
            }
        }
    }

    /** The digest of everything fed in. The hasher is used up: start again with `init`. */
    finish(this: *Sha256): u8[32] {
        const bits = this.length *% 8;
        const one: u8[1] = [0x80];
        const zero: u8[1] = [0];
        this.update(&one);
        while (this.used != 56) this.update(&zero);
        let length: u8[8] = undefined;
        for (const i of 0..8) length[i] = @truncate(u8, bits >> (56 - i * 8) as u64);
        this.update(&length);
        let digest: u8[32] = undefined;
        for (const i of 0..8) {
            digest[i * 4] = @truncate(u8, this.state[i] >> 24);
            digest[i * 4 + 1] = @truncate(u8, this.state[i] >> 16);
            digest[i * 4 + 2] = @truncate(u8, this.state[i] >> 8);
            digest[i * 4 + 3] = @truncate(u8, this.state[i]);
        }
        return digest;
    }

    compress(this: *Sha256): void {
        let w: u32[64] = undefined;
        for (const i of 0..16) {
            w[i] = (this.block[i * 4] as u32) << 24 | (this.block[i * 4 + 1] as u32) << 16 |
                   (this.block[i * 4 + 2] as u32) << 8 | (this.block[i * 4 + 3] as u32);
        }
        for (const i of 16..64) {
            const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
            const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16] +% s0 +% w[i - 7] +% s1;
        }
        let a = this.state[0];
        let b = this.state[1];
        let c = this.state[2];
        let d = this.state[3];
        let e = this.state[4];
        let f = this.state[5];
        let g = this.state[6];
        let h = this.state[7];
        for (const i of 0..64) {
            const t1 = h +% (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) +% ((e & f) ^ (~e & g)) +% K[i] +% w[i];
            const t2 = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) +% ((a & b) ^ (a & c) ^ (b & c));
            h = g;
            g = f;
            f = e;
            e = d +% t1;
            d = c;
            c = b;
            b = a;
            a = t1 +% t2;
        }
        this.state[0] +%= a;
        this.state[1] +%= b;
        this.state[2] +%= c;
        this.state[3] +%= d;
        this.state[4] +%= e;
        this.state[5] +%= f;
        this.state[6] +%= g;
        this.state[7] +%= h;
    }
}

/** The SHA-256 digest of `bytes`. */
export function sha256(bytes: readonly u8[]): u8[32] {
    let h = Sha256.init();
    h.update(bytes);
    return h.finish();
}

/** A digest as 64 lowercase hex digits. */
export function toHex(digest: u8[32]): u8[64] {
    const digits = "0123456789abcdef";
    let text: u8[64] = undefined;
    for (const b, i of digest) {
        text[i * 2] = digits[b >> 4];
        text[i * 2 + 1] = digits[b & 15];
    }
    return text;
}
