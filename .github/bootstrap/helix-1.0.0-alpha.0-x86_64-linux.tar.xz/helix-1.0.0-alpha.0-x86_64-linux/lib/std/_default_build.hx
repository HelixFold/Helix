/** The build.hx of a project without one: the runner's own steps (helix.jsonc's `bin`, `run`, `test`) are all it needs. */

import { Build } from "./build";

export function build(_b: *Build): void | Error {}
