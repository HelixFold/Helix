/** Checks for things that must be true. */

/**
 * Panics with `message` when `ok` is false. At compile time (`comptime { assert(...) }`) a failed assertion is a
 * compile error instead.
 */
export function assert(ok: bool, message: string): void {
    if (!ok) @panic(message);
}
