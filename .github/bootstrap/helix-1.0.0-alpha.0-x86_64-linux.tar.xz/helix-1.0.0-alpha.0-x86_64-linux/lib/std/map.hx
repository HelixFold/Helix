/**
 * A hash map with open addressing. How keys are hashed and compared is passed in, so nothing is hidden:
 *
 *     let ages = HashMap<string, u32>.init(allocator, hashString, equal);
 *     try ages.put("ada", 36);
 *     const age = ages.get("ada") ?? 0;
 *
 * `hashString` and `hashInt` cover the common keys; `equal` (std/text) compares strings. Keys and values are
 * stored as they are: a `string` key's bytes must outlive the map (copy them first if they don't).
 */

import { Allocator, AllocError, alloc, free } from "./heap";

const EMPTY: u8 = 0;
const FULL: u8 = 1;
const REMOVED: u8 = 2;   // a tombstone: lookups go on past it, inserts may reuse it

/** One key and its value, as the iterator hands them out. */
export struct Entry<K, V> {
    key: K,
    value: V,
}

export struct HashMap<K, V> {
    keys: K[],
    values: V[],
    states: u8[],
    count: usize,       // keys present
    used: usize,        // slots that aren't EMPTY: present keys and tombstones
    allocator: dyn Allocator,
    hash: (key: K) => u64,
    eql: (a: K, b: K) => bool,

    init(allocator: dyn Allocator, hash: (key: K) => u64, eql: (a: K, b: K) => bool): HashMap<K, V> {
        return HashMap<K, V> { keys: [], values: [], states: [], count: 0, used: 0, allocator, hash, eql };
    }

    deinit(this: *HashMap<K, V>): void {
        if (this.states.len > 0) {
            free(this.allocator, this.keys);
            free(this.allocator, this.values);
            free(this.allocator, this.states);
        }
        this.keys = [];
        this.values = [];
        this.states = [];
        this.count = 0;
        this.used = 0;
    }

    /** How many keys the map holds. */
    len(this: readonly *HashMap<K, V>): usize {
        return this.count;
    }

    /** The slot holding `key`, or null. */
    find(this: readonly *HashMap<K, V>, key: K): ?usize {
        if (this.states.len == 0) return null;
        const hashOf = this.hash;
        const same = this.eql;
        const mask = this.states.len - 1;
        let i = @truncate(usize, hashOf(key)) & mask;
        while (true) {
            const state = this.states[i];
            if (state == EMPTY) return null;
            if (state == FULL && same(this.keys[i], key)) return i;
            i = (i + 1) & mask;
        }
    }

    /** The value for `key`, or null when it isn't there. */
    get(this: readonly *HashMap<K, V>, key: K): ?V {
        if (const i = this.find(key)) return this.values[i];
        return null;
    }

    /** Where the value for `key` is, to change it in place; null when it isn't there. Valid until the map grows. */
    getPtr(this: *HashMap<K, V>, key: K): ?*V {
        if (const i = this.find(key)) return &this.values[i];
        return null;
    }

    contains(this: readonly *HashMap<K, V>, key: K): bool {
        return this.find(key) != null;
    }

    /** Sets the value for `key`, replacing the one it had. */
    put(this: *HashMap<K, V>, key: K, value: V): void | AllocError {
        if (const i = this.find(key)) {
            this.values[i] = value;
            return;
        }
        if ((this.used + 1) * 4 > this.states.len * 3) try this.grow();
        const hashOf = this.hash;
        const mask = this.states.len - 1;
        let i = @truncate(usize, hashOf(key)) & mask;
        while (this.states[i] == FULL) i = (i + 1) & mask;
        if (this.states[i] == EMPTY) this.used++;
        this.states[i] = FULL;
        this.keys[i] = key;
        this.values[i] = value;
        this.count++;
    }

    /** Removes `key`; whether it was there. */
    remove(this: *HashMap<K, V>, key: K): bool {
        const found = this.find(key);
        if (found == null) return false;
        this.states[found] = REMOVED;
        this.count--;
        return true;
    }

    /** Every key and value, in no particular order. Changing the map while iterating isn't allowed. */
    iterator(this: readonly *HashMap<K, V>): HashMapIterator<K, V> {
        return HashMapIterator<K, V> { map: this, next_slot: 0 };
    }

    /** Twice the slots (8 at first), with the keys put back and the tombstones dropped. */
    grow(this: *HashMap<K, V>): void | AllocError {
        const size = this.states.len == 0 ? 8 : this.states.len * 2;
        const oldKeys = this.keys;
        const oldValues = this.values;
        const oldStates = this.states;
        this.keys = try alloc<K>(this.allocator, size);
        this.values = try alloc<V>(this.allocator, size);
        this.states = try alloc<u8>(this.allocator, size);
        for (const i of 0..size) this.states[i] = EMPTY;
        this.count = 0;
        this.used = 0;
        const hashOf = this.hash;
        const mask = size - 1;
        for (const state, i of oldStates) {
            if (state != FULL) continue;
            let j = @truncate(usize, hashOf(oldKeys[i])) & mask;
            while (this.states[j] == FULL) j = (j + 1) & mask;
            this.states[j] = FULL;
            this.keys[j] = oldKeys[i];
            this.values[j] = oldValues[i];
            this.count++;
            this.used++;
        }
        if (oldStates.len > 0) {
            free(this.allocator, oldKeys);
            free(this.allocator, oldValues);
            free(this.allocator, oldStates);
        }
    }
}

export struct HashMapIterator<K, V> {
    map: readonly *HashMap<K, V>,
    next_slot: usize,

    next(this: *HashMapIterator<K, V>): ?Entry<K, V> {
        while (this.next_slot < this.map.states.len) {
            const i = this.next_slot;
            this.next_slot++;
            if (this.map.states[i] == FULL) return Entry<K, V> { key: this.map.keys[i], value: this.map.values[i] };
        }
        return null;
    }
}

/** FNV-1a over the bytes, finished with a mix so the low bits (which pick the slot) depend on all of them. */
export function hashString(text: string): u64 {
    let h: u64 = 0xcbf29ce484222325;
    for (const c of text) {
        h ^= c as u64;
        h = h *% 0x100000001b3;
    }
    return hashInt(h);
}

/** splitmix64's finisher: spreads an integer key's bits over the whole hash. */
export function hashInt(x: u64): u64 {
    let z = x +% 0x9e3779b97f4a7c15;
    z = (z ^ (z >> 30)) *% 0xbf58476d1ce4e5b9;
    z = (z ^ (z >> 27)) *% 0x94d049bb133111eb;
    return z ^ (z >> 31);
}

/** Whether two integers are equal, for maps with integer keys. */
export function eqlInt(a: u64, b: u64): bool {
    return a == b;
}
