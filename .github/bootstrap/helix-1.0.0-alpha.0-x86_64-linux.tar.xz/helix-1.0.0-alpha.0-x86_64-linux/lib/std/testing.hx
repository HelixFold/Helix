/**
 * Test support for `helix test`. A test build makes this module visible as `testing` without an import.
 *
 *   testing.allocator   detects leaks: memory a test allocates and doesn't free fails the test
 *
 * `describe`, `test`, the hooks, `expect` and `require` are built into the language; see docs/design/testing.md.
 */

import { Allocator, DebugAllocator, cAllocator } from "./heap";

/** What `require(...)` returns when its check fails, so `try` stops the test. */
export error TestError { RequireFailed }

let debug: DebugAllocator = undefined;

/** An allocator for tests. Each test gets a fresh one, and anything still allocated when it ends fails it. */
export let allocator: dyn Allocator = undefined;

/** Runs before each test's hooks. */
export function _begin(): void {
    debug = DebugAllocator.init(cAllocator());
    allocator = debug.allocator();
}

/** Runs after each test's hooks; returns how many allocations leaked (each is reported on stderr). */
export function _end(): usize {
    return debug.deinit();
}
