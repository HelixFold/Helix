/** Number helpers that work for every integer and float type. */

/** The smaller of `a` and `b`. */
export function min<T extends Numeric>(a: T, b: T): T {
    return a < b ? a : b;
}

/** The larger of `a` and `b`. */
export function max<T extends Numeric>(a: T, b: T): T {
    return a > b ? a : b;
}

/** `value` limited to the range `lo..=hi`. */
export function clamp<T extends Numeric>(value: T, lo: T, hi: T): T {
    return value < lo ? lo : value > hi ? hi : value;
}

/** The distance of `value` from zero. Panics on the most negative integer, which has no positive counterpart. */
export function abs<T extends Numeric>(value: T): T {
    return value < 0 ? 0 - value : value;
}
