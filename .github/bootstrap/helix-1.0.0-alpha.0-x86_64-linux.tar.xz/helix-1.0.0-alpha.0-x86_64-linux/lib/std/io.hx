/**
 * Output. A `Writer` takes bytes; formatting a template into one is `fprint(w, `...`)`.
 *
 * `stdout()` and `stderr()` share their buffers with `print` and `eprint`, so output from both comes out in order.
 */

/** Anything that takes bytes: a file, a buffer, a socket. Formatting calls only `write`. */
export interface Writer {
    /** Takes all of `bytes`, or fails. */
    write(this: *Self, bytes: readonly u8[]): void | Error;
}

/** Anything that gives bytes: a file, stdin, a socket. */
export interface Reader {
    /** Reads into `buf` and returns how many bytes it got; 0 means there's nothing more. */
    read(this: *Self, buf: u8[]): usize | Error;
}

/** Writes a template (or a plain string) to `w`. */
export function fprint(w: dyn Writer, text: Format): void | Error {
    try text.writeTo(w);
}

/** `fprint`, then a newline. */
export function fprintln(w: dyn Writer, text: Format): void | Error {
    try text.writeTo(w);
    try w.write("\n");
}

extern "C" function hx_write(fd: i32, bytes: readonly u8[*], len: usize): void;

struct Stdout {
    write(this: *Stdout, bytes: readonly u8[]): void | Error {
        hx_write(1, bytes.ptr, bytes.len);
    }
}

struct Stderr {
    write(this: *Stderr, bytes: readonly u8[]): void | Error {
        hx_write(2, bytes.ptr, bytes.len);
    }
}

let stdoutWriter: Stdout = undefined;   // no fields, so nothing to initialize
let stderrWriter: Stderr = undefined;

export function stdout(): dyn Writer {
    return &stdoutWriter;
}

export function stderr(): dyn Writer {
    return &stderrWriter;
}
