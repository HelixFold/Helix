/** The few C library functions the standard library builds on. Private to std. */

export extern "C" function malloc(size: usize): ?u8[*];
export extern "C" function realloc(ptr: ?u8[*], size: usize): ?u8[*];
export extern "C" function free(ptr: ?u8[*]): void;
export extern "C" function memcpy(dest: u8[*], source: readonly u8[*], count: usize): u8[*];
export extern "C" function strlen(text: readonly u8[*]): usize;
export extern "C" function exit(code: i32): noreturn;
