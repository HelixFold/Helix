/**
 * Sorting in place, with the order given as a function:
 *
 *     sort(scores, (a: i32, b: i32): bool => a < b);          // ascending
 *     sort(users, (a: User, b: User): bool => a.age > b.age); // oldest first
 *
 * Quicksort with a median-of-three pivot, insertion sort for short runs, and heapsort when the recursion gets deep,
 * so it's O(n log n) on any input and needs no memory. It isn't stable: equal items may change order.
 */

/** Sorts `items` so that `less(items[i + 1], items[i])` is false everywhere. */
export function sort<T>(items: T[], less: (a: T, b: T) => bool): void {
    let depth: u32 = 0;
    let n = items.len;
    while (n > 1) {   // 2 * log2(n): past that, quicksort is hitting bad pivots
        depth += 2;
        n /= 2;
    }
    sortRange(items, less, depth);
}

/** Whether `items` are in the order `less` gives. */
export function isSorted<T>(items: readonly T[], less: (a: T, b: T) => bool): bool {
    for (const i of 1..items.len) {
        if (less(items[i], items[i - 1])) return false;
    }
    return true;
}

function swap<T>(items: T[], i: usize, j: usize): void {
    const x = items[i];
    items[i] = items[j];
    items[j] = x;
}

function insertion<T>(items: T[], less: (a: T, b: T) => bool): void {
    for (const i of 1..items.len) {
        const x = items[i];
        let j = i;
        while (j > 0 && less(x, items[j - 1])) {
            items[j] = items[j - 1];
            j--;
        }
        items[j] = x;
    }
}

function siftDown<T>(items: T[], less: (a: T, b: T) => bool, start: usize, end: usize): void {
    let root = start;
    while (root * 2 + 1 < end) {
        let child = root * 2 + 1;
        if (child + 1 < end && less(items[child], items[child + 1])) child++;
        if (!less(items[root], items[child])) return;
        swap(items, root, child);
        root = child;
    }
}

function heapsort<T>(items: T[], less: (a: T, b: T) => bool): void {
    let start = items.len / 2;
    while (start > 0) {
        start--;
        siftDown(items, less, start, items.len);
    }
    let end = items.len;
    while (end > 1) {
        end--;
        swap(items, 0, end);
        siftDown(items, less, 0, end);
    }
}

function sortRange<T>(items: T[], less: (a: T, b: T) => bool, depth: u32): void {
    let part = items;
    let budget = depth;
    while (part.len > 16) {
        if (budget == 0) {
            heapsort(part, less);
            return;
        }
        budget--;
        // the median of the first, middle and last items goes last, as the pivot
        const mid = part.len / 2;
        const last = part.len - 1;
        if (less(part[mid], part[0])) swap(part, mid, 0);
        if (less(part[last], part[0])) swap(part, last, 0);
        if (less(part[mid], part[last])) swap(part, mid, last);
        const pivot = part[last];
        let store: usize = 0;
        for (const i of 0..last) {
            if (less(part[i], pivot)) {
                swap(part, i, store);
                store++;
            }
        }
        swap(part, store, last);
        // the smaller side recursively, the larger one in this loop: the stack stays O(log n)
        if (store < part.len - store - 1) {
            sortRange(part[0..store], less, budget);
            part = part[store + 1..];
        } else {
            sortRange(part[store + 1..], less, budget);
            part = part[0..store];
        }
    }
    insertion(part, less);
}
