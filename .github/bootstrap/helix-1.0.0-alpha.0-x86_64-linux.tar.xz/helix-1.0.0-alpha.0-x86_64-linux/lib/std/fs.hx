/**
 * Files.
 *
 *   const text = try fs.readFile(a, "notes.txt");      // the whole file, in memory from `a`
 *   try fs.writeFile("out.txt", text);
 *
 *   let file = try File.create("log.txt");
 *   defer file.close();
 *   try fprintln(&file, `started at ${t}`);             // a `*File` is a `dyn Writer` (and a `dyn Reader`)
 *
 *   let dir = try Dir.open("src");                     // the names in a folder
 *   defer dir.close();
 *   while (const name = try dir.next()) println(name);
 *
 *   const info = try fs.stat("notes.txt");             // size, modification time, kind
 *   try fs.rename("a.txt", "b.txt");
 *   try fs.deleteTree("build");                        // rm -rf; never follows symbolic links
 */

import { Allocator, alloc, resize, free } from "./heap";

export error FsError { NotFound, AccessDenied, IsDirectory, AlreadyExists, NoSpace, NameTooLong, Unexpected }

extern "C" function hx_fs_open(path: readonly u8[*], len: usize, mode: i32): i64;
extern "C" function hx_fs_read(fd: i32, buf: u8[*], len: usize): i64;
extern "C" function hx_fs_write(fd: i32, bytes: readonly u8[*], len: usize): i64;
extern "C" function hx_fs_close(fd: i32): void;
extern "C" function hx_fs_size(fd: i32): i64;
extern "C" function hx_fs_delete(path: readonly u8[*], len: usize): i64;
extern "C" function hx_fs_make_path(path: readonly u8[*], len: usize): i64;
extern "C" function hx_fs_copy(from: readonly u8[*], from_len: usize, to: readonly u8[*], to_len: usize): i64;
extern "C" function hx_fs_stat(path: readonly u8[*], len: usize, follow: i32, out: *RawStat): i64;
extern "C" function hx_fs_dir_open(path: readonly u8[*], len: usize): i64;
extern "C" function hx_fs_dir_next(handle: i64, out: u8[*], cap: usize): i64;
extern "C" function hx_fs_dir_close(handle: i64): void;
extern "C" function hx_fs_rename(from: readonly u8[*], from_len: usize, to: readonly u8[*], to_len: usize): i64;
extern "C" function hx_fs_delete_tree(path: readonly u8[*], len: usize): i64;
extern "C" function hx_fs_symlink(target: readonly u8[*], target_len: usize, path: readonly u8[*], len: usize): i64;
extern "C" function hx_fs_read_link(path: readonly u8[*], len: usize, out: u8[*], cap: usize): i64;

/** HxStat in lib/rt/runtime.c. */
extern "C" struct RawStat {
    size: i64,
    mtime: i64,
    kind: i32,
    mode: u32,
}

/** A runtime result: the value, or the error its negative code stands for (see lib/rt/runtime.c). */
function check(result: i64): u64 | FsError {
    if (result >= 0) return result as u64;
    const errors: FsError[7] = [
        FsError.NotFound, FsError.AccessDenied, FsError.IsDirectory, FsError.AlreadyExists,
        FsError.NoSpace, FsError.NameTooLong, FsError.Unexpected,
    ];
    const code = (-result) as usize;
    throw code <= errors.len ? errors[code - 1] : FsError.Unexpected;
}

/** An open file. Close it when done: `defer file.close();` */
export struct File {
    fd: i32,

    /** Opens an existing file for reading. */
    open(path: string): File | FsError {
        return File.at(try check(hx_fs_open(path.ptr, path.len, 0)));
    }

    /** Opens a file for writing, creating it or emptying it. */
    create(path: string): File | FsError {
        return File.at(try check(hx_fs_open(path.ptr, path.len, 1)));
    }

    /** Opens a file for writing at its end, creating it if needed. */
    append(path: string): File | FsError {
        return File.at(try check(hx_fs_open(path.ptr, path.len, 2)));
    }

    /** Creates a new file for writing; fails with `AlreadyExists` if there is one. */
    createNew(path: string): File | FsError {
        return File.at(try check(hx_fs_open(path.ptr, path.len, 3)));
    }

    /** The program's standard input. */
    stdin(): File {
        return File { fd: 0 };
    }

    at(fd: u64): File {
        return File { fd: fd as i32 };
    }

    close(this: *File): void {
        hx_fs_close(this.fd);
        this.fd = -1;
    }

    /** Reads into `buf` and returns how many bytes it got; 0 means the end of the file. */
    read(this: *File, buf: u8[]): usize | Error {
        return (try check(hx_fs_read(this.fd, buf.ptr, buf.len))) as usize;
    }

    /** Writes all of `bytes`. Every call is a system call; build big outputs first, then write them. */
    write(this: *File, bytes: readonly u8[]): void | Error {
        void try check(hx_fs_write(this.fd, bytes.ptr, bytes.len));
    }

    /** The rest of the file, in memory from `a`. Works for pipes and stdin too. */
    readAll(this: *File, a: dyn Allocator): u8[] | Error {
        const size = (check(hx_fs_size(this.fd)) catch 0) as usize;
        let buf = try alloc<u8>(a, size > 0 ? size + 1 : 4096);
        errdefer free(a, buf);
        let len: usize = 0;
        while (true) {
            if (len == buf.len) buf = try resize(a, buf, buf.len * 2);
            const n = try this.read(buf[len..buf.len]);
            if (n == 0) break;
            len += n;
        }
        return try resize(a, buf, len);
    }
}

/** The whole file at `path`, in memory from `a`. Give it back with `free(a, bytes)`. */
export function readFile(a: dyn Allocator, path: string): u8[] | Error {
    let file = try File.open(path);
    defer file.close();
    return try file.readAll(a);
}

/** Replaces the file at `path` with `bytes`, creating it if needed. */
export function writeFile(path: string, bytes: readonly u8[]): void | Error {
    let file = try File.create(path);
    defer file.close();
    try file.write(bytes);
}

export function deleteFile(path: string): void | Error {
    void try check(hx_fs_delete(path.ptr, path.len));
}

/** Creates the folder at `path`, and any missing folders above it. A folder that's already there is fine. */
export function makePath(path: string): void | Error {
    void try check(hx_fs_make_path(path.ptr, path.len));
}

/** Copies the file at `from` to `to`, replacing `to` and keeping the permissions (an executable stays one). */
export function copyFile(from: string, to: string): void | Error {
    void try check(hx_fs_copy(from.ptr, from.len, to.ptr, to.len));
}

/* ---- folders, metadata, links ---- */

export enum Kind { File, Directory, Link, Other }

/** What `stat` says about a path. */
export struct Stat {
    size: u64,
    mtime: i64,         // the last modification, in seconds since 1970
    kind: Kind,
    mode: u32,          // the permission bits, like 0o755
}

function statOf(path: string, follow: bool): Stat | FsError {
    let raw = RawStat { size: 0, mtime: 0, kind: 0, mode: 0 };
    void try check(hx_fs_stat(path.ptr, path.len, follow ? 1 : 0, &raw));
    const kinds: Kind[4] = [Kind.File, Kind.Directory, Kind.Link, Kind.Other];
    return Stat { size: raw.size as u64, mtime: raw.mtime, kind: kinds[raw.kind as usize], mode: raw.mode };
}

/** What `path` is, following symbolic links. */
export function stat(path: string): Stat | FsError {
    return try statOf(path, true);
}

/** What `path` is, without following a symbolic link: a link is reported as `Kind.Link`. */
export function linkStat(path: string): Stat | FsError {
    return try statOf(path, false);
}

/** Whether anything is at `path` (a link counts, even a broken one). */
export function exists(path: string): bool {
    let raw = RawStat { size: 0, mtime: 0, kind: 0, mode: 0 };
    return hx_fs_stat(path.ptr, path.len, 0, &raw) == 0;
}

/**
 * The names in a folder, one at a time, without `.` and `..`, in the order the OS lists them. `next` returns a name
 * that's valid until the next call; copy it to keep it.
 */
export struct Dir {
    handle: i64,
    name: u8[256],

    open(path: string): Dir | FsError {
        return Dir { handle: try check(hx_fs_dir_open(path.ptr, path.len)) as i64, name: undefined };
    }

    close(this: *Dir): void {
        if (this.handle != 0) hx_fs_dir_close(this.handle);
        this.handle = 0;
    }

    /** The next name, or null when there are no more. */
    next(this: *Dir): ?string | FsError {
        const n = try check(hx_fs_dir_next(this.handle, &this.name, this.name.len));
        if (n == 0) return null;
        const name: *u8[256] = &this.name;
        return name[0..n as usize];
    }
}

/** Renames or moves a file or folder (on the same file system), replacing a file at `to`. */
export function rename(from: string, to: string): void | Error {
    void try check(hx_fs_rename(from.ptr, from.len, to.ptr, to.len));
}

/** Deletes a file or a folder and everything in it. A symbolic link is deleted itself, never what it points at. */
export function deleteTree(path: string): void | Error {
    void try check(hx_fs_delete_tree(path.ptr, path.len));
}

/** Makes `path` a symbolic link holding `target`. */
export function makeLink(target: string, path: string): void | Error {
    void try check(hx_fs_symlink(target.ptr, target.len, path.ptr, path.len));
}

/** What the symbolic link at `path` holds, in memory from `a`. */
export function readLink(a: dyn Allocator, path: string): u8[] | Error {
    let buf: u8[1024] = undefined;
    const n = try check(hx_fs_read_link(path.ptr, path.len, &buf, buf.len)) as usize;
    const out = try alloc<u8>(a, n);
    for (const i of 0..n) out[i] = buf[i];
    return out;
}
