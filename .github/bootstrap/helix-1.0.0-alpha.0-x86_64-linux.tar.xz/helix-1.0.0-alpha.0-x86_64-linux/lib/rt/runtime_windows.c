/*
 * The Helix runtime for Windows. Programs import from msvcrt.dll and kernel32.dll, which every Windows has, so they
 * need no C library of their own. This file declares exactly what it uses from them instead of including Windows'
 * headers, so building for Windows needs nothing but LLVM. It provides the same functions as runtime.c, plus what
 * the C startup files would: the entry point, and the C functions generated code calls that msvcrt lacks
 * (`dprintf`, a C99 `snprintf`).
 *
 * With HX_WITH_C_RUNTIME, for a program linked with mingw-w64's C runtime (the compiler itself, whose LLVM is C++),
 * the entry point and what that runtime has are left to it.
 */

#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* ---- what msvcrt.dll and kernel32.dll provide ---- */

#if defined(HX_WITH_C_RUNTIME)   /* the C runtime's import libraries say where each function is */
#define IMPORT
#define _vsnprintf vsnprintf     /* the UCRT has C99's, and no _vsnprintf to import */
#else
#define IMPORT __declspec(dllimport)
#endif

typedef void *HANDLE;
typedef uint32_t DWORD;

IMPORT HANDLE __stdcall GetStdHandle(DWORD which);
IMPORT int __stdcall WriteFile(HANDLE file, const void *bytes, DWORD len, DWORD *written, void *overlapped);
IMPORT uint16_t __stdcall RtlCaptureStackBackTrace(DWORD skip, DWORD count, void **frames, DWORD *hash);
IMPORT void *__stdcall GetModuleHandleA(const char *name);
IMPORT int __stdcall CopyFileA(const char *from, const char *to, int fail_if_exists);
IMPORT DWORD __stdcall GetLastError(void);

#define STD_OUTPUT_HANDLE ((DWORD)-11)
#define STD_ERROR_HANDLE ((DWORD)-12)

typedef struct { int newmode; } StartupInfo;
IMPORT int __getmainargs(int *argc, char ***argv, char ***env, int glob, StartupInfo *info);
IMPORT void exit(int code);
IMPORT void abort(void);
IMPORT int _vsnprintf(char *buf, size_t size, const char *fmt, va_list args);
IMPORT double strtod(const char *text, char **end);
IMPORT char *strchr(const char *text, int c);
IMPORT size_t strlen(const char *text);
IMPORT void *memmove(void *to, const void *from, size_t n);
IMPORT void *memcpy(void *to, const void *from, size_t n);
IMPORT int atoi(const char *text);
IMPORT char *getenv(const char *name);
IMPORT int *_errno(void);
IMPORT int _open(const char *path, int flags, ...);
IMPORT int _read(int fd, void *buf, unsigned len);
IMPORT int _write(int fd, const void *buf, unsigned len);
IMPORT int _close(int fd);
IMPORT int64_t _filelengthi64(int fd);
IMPORT int _unlink(const char *path);
IMPORT int _mkdir(const char *path);
IMPORT intptr_t _spawnvp(int mode, const char *file, const char *const *argv);
IMPORT void *malloc(size_t size);
IMPORT void free(void *p);

/* ---- what the C startup files and a C99 library would provide ---- */

#if !defined(HX_WITH_C_RUNTIME)
int main(int argc, char **argv);

/** The entry point: what crt2.o is for MinGW programs. */
void mainCRTStartup(void) {
    int argc;
    char **argv, **env;
    StartupInfo info = { 0 };
    __getmainargs(&argc, &argv, &env, 0, &info);
    exit(main(argc, argv));
}

/** MinGW's code generation calls `__main` at the top of `main` to run constructors; Helix has none. */
void __main(void) {}

/** C99 `snprintf`, which always NUL-terminates and returns the full length (msvcrt's `_snprintf` doesn't). */
int snprintf(char *buf, size_t size, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    int n = _vsnprintf(buf, size, fmt, args);
    va_end(args);
    if (size > 0 && (n < 0 || (size_t)n >= size)) {
        buf[size - 1] = '\0';
        if (n < 0) {   // too small: measure with a bigger buffer
            char big[1024];
            va_start(args, fmt);
            n = _vsnprintf(big, sizeof big, fmt, args);
            va_end(args);
            if (n < 0) n = (int)sizeof big;
        }
    }
    return n;
}
#else
int snprintf(char *buf, size_t size, const char *fmt, ...);   /* the C runtime's, a C99 one */
#endif

static void write_handle(DWORD which, const char *bytes, size_t len) {
    HANDLE h = GetStdHandle(which);
    while (len > 0) {
        DWORD written = 0;
        if (!WriteFile(h, bytes, (DWORD)len, &written, NULL) || written == 0) return;
        bytes += written;
        len -= written;
    }
}

/** `dprintf(2, ...)`: the panic handler's output. */
int dprintf(int fd, const char *fmt, ...) {
    char buf[4096];
    va_list args;
    va_start(args, fmt);
    int n = _vsnprintf(buf, sizeof buf, fmt, args);
    va_end(args);
    if (n < 0 || n >= (int)sizeof buf) n = (int)sizeof buf - 1;
    write_handle(fd == 1 ? STD_OUTPUT_HANDLE : STD_ERROR_HANDLE, buf, (size_t)n);
    return n;
}

#if !defined(HX_WITH_C_RUNTIME)
/** Output isn't buffered here, so there's nothing to flush; generated code calls it before a panic. */
int fflush(void *stream) {
    (void)stream;
    return 0;
}
#endif

static float strtof_(const char *text, char **end) {
    return (float)strtod(text, end);
}
#define strtof strtof_

/* ---- output and formatting ---- */

void hx_write(int32_t fd, const char *bytes, size_t len) {
    if (len == 0) return;
    if (fd <= 2) {
        write_handle(fd == 2 ? STD_ERROR_HANDLE : STD_OUTPUT_HANDLE, bytes, len);
        return;
    }
    _write(fd, bytes, (unsigned)len);
}

#define HX_I64 "I64d"
#define HX_U64 "I64u"
#define HX_X64 "I64x"
#include "format.inc"

/* ---- files ---- */

enum { FS_NOT_FOUND = 1, FS_ACCESS_DENIED, FS_IS_DIRECTORY, FS_ALREADY_EXISTS, FS_NO_SPACE, FS_NAME_TOO_LONG, FS_UNEXPECTED };

static int64_t fs_error(void) {
    switch (*_errno()) {
    case 2: return -FS_NOT_FOUND;        // ENOENT
    case 13: return -FS_ACCESS_DENIED;   // EACCES
    case 21: return -FS_IS_DIRECTORY;    // EISDIR
    case 17: return -FS_ALREADY_EXISTS;  // EEXIST
    case 28: return -FS_NO_SPACE;        // ENOSPC
    case 38: return -FS_NAME_TOO_LONG;   // ENAMETOOLONG
    default: return -FS_UNEXPECTED;
    }
}

/** A Helix string as a C string, in `out` (MAX_PATH-sized paths are plenty here). */
static bool fs_path(char *out, const char *path, size_t len) {
    if (len >= 4096) return false;
    memcpy(out, path, len);
    out[len] = '\0';
    return true;
}

int64_t hx_fs_open(const char *path, size_t len, int32_t mode) {
    // the same modes as runtime.c: read, create (truncate), append, create only if new
    static const int flags[] = { 0x8000, 0x8000 | 0x1 | 0x100 | 0x200, 0x8000 | 0x1 | 0x100 | 0x8, 0x8000 | 0x1 | 0x100 | 0x400 };
    char name[4096];
    if (!fs_path(name, path, len)) return -FS_NAME_TOO_LONG;
    if (mode < 0 || mode > 3) return -FS_UNEXPECTED;
    int fd = _open(name, flags[mode], 0x180);   // _S_IREAD | _S_IWRITE
    return fd < 0 ? fs_error() : fd;
}

int64_t hx_fs_read(int32_t fd, char *buf, size_t len) {
    int n = _read(fd, buf, (unsigned)(len > 0x7fffffff ? 0x7fffffff : len));
    return n < 0 ? fs_error() : n;
}

int64_t hx_fs_write(int32_t fd, const char *bytes, size_t len) {
    while (len > 0) {
        int n = _write(fd, bytes, (unsigned)(len > 0x7fffffff ? 0x7fffffff : len));
        if (n <= 0) return fs_error();
        bytes += n;
        len -= (size_t)n;
    }
    return 0;
}

void hx_fs_close(int32_t fd) {
    _close(fd);
}

int64_t hx_fs_size(int32_t fd) {
    int64_t size = _filelengthi64(fd);
    return size < 0 ? fs_error() : size;
}

int64_t hx_fs_make_path(const char *path, size_t len) {
    char name[4096];
    if (!fs_path(name, path, len)) return -FS_NAME_TOO_LONG;
    for (char *p = name + 1;; p++) {
        if (*p != '/' && *p != '\\' && *p != '\0') continue;
        char saved = *p;
        *p = '\0';
        if (_mkdir(name) != 0 && *_errno() != 17) return fs_error();
        *p = saved;
        if (!saved) return 0;
    }
}

int64_t hx_fs_copy(const char *from, size_t from_len, const char *to, size_t to_len) {
    char src[4096], dst[4096];
    if (!fs_path(src, from, from_len) || !fs_path(dst, to, to_len)) return -FS_NAME_TOO_LONG;
    if (CopyFileA(src, dst, 0)) return 0;
    return GetLastError() == 2 || GetLastError() == 3 ? -FS_NOT_FOUND : -FS_UNEXPECTED;
}

int64_t hx_fs_delete(const char *path, size_t len) {
    char name[4096];
    if (!fs_path(name, path, len)) return -FS_NAME_TOO_LONG;
    return _unlink(name) == 0 ? 0 : fs_error();
}

const char *hx_getenv(const char *name, size_t len) {
    char key[4096];
    if (!fs_path(key, name, len)) return NULL;
    return getenv(key);
}

/* ---- processes ---- */

typedef struct {
    const char *ptr;
    size_t len;
} HxString;

/** An argument quoted the way Windows programs split their command line (CommandLineToArgvW's rules). */
static char *quote(const char *text, size_t len) {
    char *out = malloc(len * 2 + 3);
    size_t n = 0;
    bool plain = len > 0;
    for (size_t i = 0; i < len && plain; i++) plain = text[i] != ' ' && text[i] != '\t' && text[i] != '"';
    if (plain) {
        memcpy(out, text, len);
        out[len] = '\0';
        return out;
    }
    out[n++] = '"';
    size_t backslashes = 0;
    for (size_t i = 0; i < len; i++) {
        if (text[i] == '\\') {
            backslashes++;
        } else {
            if (text[i] == '"') {   // backslashes before a quote are doubled, and the quote escaped
                for (size_t b = 0; b <= backslashes; b++) out[n++] = '\\';
            }
            backslashes = 0;
        }
        out[n++] = text[i];
    }
    for (size_t b = 0; b < backslashes; b++) out[n++] = '\\';   // and before the closing quote
    out[n++] = '"';
    out[n] = '\0';
    return out;
}

int64_t hx_process_run(const HxString *argv, size_t count) {
    if (count == 0) return -1;
    char **args = malloc((count + 1) * sizeof(char *));
    for (size_t i = 0; i < count; i++) args[i] = quote(argv[i].ptr, argv[i].len);
    args[count] = NULL;
    intptr_t status = _spawnvp(0 /* _P_WAIT */, args[0], (const char *const *)args);
    for (size_t i = 0; i < count; i++) free(args[i]);
    free(args);
    return status < 0 ? -1 : (int64_t)(status & 0xff);
}

/* ---- stack traces ---- */

/** Addresses, as offsets into the program, so `llvm-symbolizer --obj=app.exe 0x...` can name them. */
void hx_stack_trace(void) {
    void *frames[64];
    uint16_t count = RtlCaptureStackBackTrace(1, 64, frames, NULL);
    char line[96];
    uintptr_t base = (uintptr_t)GetModuleHandleA(NULL);
    write_handle(STD_ERROR_HANDLE, "stack trace (offsets into the program):\n", 41);
    for (uint16_t i = 0; i < count; i++) {
        int n = snprintf(line, sizeof line, "  at +0x%" HX_X64 "\n", (unsigned long long)((uintptr_t)frames[i] - base));
        write_handle(STD_ERROR_HANDLE, line, (size_t)n);
    }
}
