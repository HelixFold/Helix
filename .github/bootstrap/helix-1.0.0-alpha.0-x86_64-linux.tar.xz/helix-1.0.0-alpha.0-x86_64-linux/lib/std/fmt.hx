/**
 * Building strings from templates. Nothing allocates unless it takes an allocator:
 *
 *   const s = try fmt.alloc(a, `id-${id}`);        // owned; give it back with `free(a, s)`
 *   const t = try fmt.bufPrint(&buf, `${x},${y}`);  // into a buffer you own
 *   let b = fmt.Builder.init(a);                    // grows as you append
 */

import { Allocator, alloc as allocBytes } from "./heap";
import { ArrayList } from "./list";
import { fprint } from "./io";

export error FormatError { NoSpaceLeft }

/** The formatted text in new memory from `a`. */
export function alloc(a: dyn Allocator, text: Format): u8[] | Error {
    const size = try count(text);
    const bytes = try allocBytes<u8>(a, size);
    void try bufPrint(bytes, text);
    return bytes;
}

/** Formats into `buf` and returns the part it used; fails with `NoSpaceLeft` if it doesn't fit. */
export function bufPrint(buf: u8[], text: Format): u8[] | Error {
    let w = BufferWriter { buf, len: 0 };
    try fprint(&w, text);
    return buf[0..w.len];
}

/** How many bytes the formatted text takes. */
export function count(text: Format): usize | Error {
    let w = CountingWriter { total: 0 };
    try fprint(&w, text);
    return w.total;
}

struct BufferWriter {
    buf: u8[],
    len: usize,

    write(this: *BufferWriter, bytes: readonly u8[]): void | Error {
        if (bytes.len > this.buf.len - this.len) throw FormatError.NoSpaceLeft;
        for (const b, i of bytes) this.buf[this.len + i] = b;
        this.len += bytes.len;
    }
}

struct CountingWriter {
    total: usize,

    write(this: *CountingWriter, bytes: readonly u8[]): void | Error {
        this.total += bytes.len;
    }
}

/** A growable string. `text()` is valid until the next append or `deinit`. */
export struct Builder {
    bytes: ArrayList<u8>,

    init(a: dyn Allocator): Builder {
        return Builder { bytes: ArrayList<u8>.init(a) };
    }

    deinit(this: *Builder): void {
        this.bytes.deinit();
    }

    /** Appends a template or a string. A `*Builder` is also a `dyn Writer`, for `fprint` and friends. */
    append(this: *Builder, text: Format): void | Error {
        try fprint(this, text);
    }

    write(this: *Builder, bytes: readonly u8[]): void | Error {
        for (const b of bytes) try this.bytes.append(b);
    }

    text(this: readonly *Builder): string {
        return this.bytes.items;
    }

    clear(this: *Builder): void {
        this.bytes.clear();
    }
}
