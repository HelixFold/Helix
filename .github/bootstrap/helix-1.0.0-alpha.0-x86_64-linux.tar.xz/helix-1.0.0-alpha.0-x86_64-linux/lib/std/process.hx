/**
 * The running program: its arguments and environment, and how it exits.
 *
 *   export function main(init: Init): void | Error {
 *       for (const arg of init.args) println(arg);
 *       const home = init.env.get("HOME") ?? "/";
 *   }
 */

import * as c from "./c";
import { Allocator, alloc, cAllocator } from "./heap";

/** What `main(init: Init)` receives. */
export struct Init {
    program: string,            // how the program was started: the first word of the command line
    args: readonly string[],    // the arguments after it
    env: Env,
}

/** The environment variables. */
export struct Env {
    /** The value of `name`, or null when it isn't set. */
    get(this: Env, name: string): ?string {
        const value = hx_getenv(name.ptr, name.len);
        if (value == null) return null;
        return cstr(value);
    }
}

export error ProcessError { CannotStart }

/**
 * Runs a program and waits for it to finish. `argv[0]` is the program, looked up in PATH like a shell does; it
 * inherits this program's stdin, stdout, stderr and environment. Returns its exit status, or 128 + the signal
 * number when a signal ended it.
 */
export function run(argv: readonly string[]): u8 | ProcessError {
    const status = hx_process_run(argv.ptr, argv.len);
    if (status < 0) throw ProcessError.CannotStart;
    return status as u8;
}

extern "C" function hx_process_run(argv: readonly string[*], count: usize): i64;
extern "C" function hx_process_capture(argv: readonly string[*], count: usize, out: *?u8[*], len: *usize): i64;

/** What `capture` got: the program's exit status and everything it wrote to stdout. */
export struct Output {
    status: u8,
    stdout: u8[],       // from the allocator passed to `capture`
}

/**
 * Runs a program like `run`, with its stdout captured into memory from `a` (stderr still goes to this program's).
 *
 *     const out = try capture(a, ["git", "rev-parse", "HEAD"]);
 *     defer free(a, out.stdout);
 */
export function capture(a: dyn Allocator, argv: readonly string[]): Output | Error {
    let raw: ?u8[*] = null;
    let len: usize = 0;
    const status = hx_process_capture(argv.ptr, argv.len, &raw, &len);
    defer c.free(raw);
    if (status < 0) throw ProcessError.CannotStart;
    const bytes = try alloc<u8>(a, len);
    if (const r = raw) {
        unsafe {
            for (const i of 0..len) bytes[i] = r[i];
        }
    }
    return Output { status: status as u8, stdout: bytes };
}

/** Ends the program with `code` as its exit status. Defers don't run; buffered output is flushed. */
export function exit(code: u8): noreturn {
    c.exit(code as i32);
}

extern "C" function hx_getenv(name: readonly u8[*], len: usize): ?readonly u8[*];

function cstr(text: readonly u8[*]): string {
    unsafe {
        return text[0..c.strlen(text)];
    }
}

/** Builds `Init` from C's `argc` and `argv`. The compiler calls this before `main(init: Init)`. */
function _startup(argc: i32, argv: readonly u8[*][*]): Init {
    const count = argc as usize;
    const words = alloc<string>(cAllocator(), count) catch @panic("out of memory reading the command line");
    for (const _, i of words) {
        unsafe {
            words[i] = cstr(argv[i]);
        }
    }
    if (count == 0) return Init { program: "", args: words, env: Env {} };
    return Init { program: words[0], args: words[1..count], env: Env {} };
}
