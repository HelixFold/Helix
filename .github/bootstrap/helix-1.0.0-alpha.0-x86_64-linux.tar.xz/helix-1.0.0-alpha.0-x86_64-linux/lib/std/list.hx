/** A growable array. */

import { Allocator, AllocError, resize, free } from "./heap";

/**
 * `items` are the values in the list; `capacity` is how many fit before it has to grow. The memory comes from the
 * allocator passed to `init` and is released by `deinit`.
 */
export struct ArrayList<T> {
    items: T[],
    capacity: usize,
    allocator: dyn Allocator,

    init(allocator: dyn Allocator): ArrayList<T> {
        return ArrayList<T> { items: [], capacity: 0, allocator };
    }

    deinit(this: *ArrayList<T>): void {
        unsafe {
            free(this.allocator, this.items.ptr[0..this.capacity]);
        }
        this.items = [];
        this.capacity = 0;
    }

    /** Adds `item` at the end, growing the storage when it's full. */
    append(this: *ArrayList<T>, item: T): void | AllocError {
        if (this.items.len == this.capacity) {
            const grown = this.capacity == 0 ? 8 : this.capacity * 2;
            unsafe {
                const storage = try resize(this.allocator, this.items.ptr[0..this.capacity], grown);
                this.items = storage[0..this.items.len];
            }
            this.capacity = grown;
        }
        unsafe {
            const len = this.items.len;
            this.items = this.items.ptr[0..len + 1];
            this.items[len] = item;
        }
    }

    /** Removes and returns the last item, or null when the list is empty. */
    pop(this: *ArrayList<T>): ?T {
        if (this.items.len == 0) return null;
        const last = this.items[this.items.len - 1];
        this.items = this.items[0..this.items.len - 1];
        return last;
    }

    /** Removes every item but keeps the storage for reuse. */
    clear(this: *ArrayList<T>): void {
        this.items = this.items[0..0];
    }
}
