/**
 * Memory. Anything that allocates takes a `dyn Allocator`, so it's always visible where memory comes from.
 *
 *   cAllocator()        the C heap (malloc/free)
 *   ArenaAllocator      bump allocation from big chunks, everything freed at once by `deinit`
 *   DebugAllocator      wraps another allocator; reports leaks and panics on bad frees
 *
 * `alloc`, `resize`, `free`, `create` and `destroy` are the typed way to use any of them.
 */

import * as c from "./c";
import { ArrayList } from "./list";

export error AllocError { OutOfMemory }

/**
 * Where memory comes from. Implement these three methods to make a new kind of allocator; code that allocates
 * calls the typed helpers below instead of these.
 */
export interface Allocator {
    /** `size` bytes aligned to `align` (a power of two), or null when there's no memory left. */
    rawAlloc(this: *Self, size: usize, align: usize): ?u8[*];

    /** `memory` grown or shrunk to `size` bytes, possibly moved, with its contents kept. Null leaves it untouched. */
    rawResize(this: *Self, memory: u8[], size: usize, align: usize): ?u8[*];

    /** Gives back memory from `rawAlloc` or `rawResize`, at the size it has now. */
    rawFree(this: *Self, memory: u8[], align: usize): void;
}

/** Room for `count` values of `T`, uninitialized. Release it with `free`. */
export function alloc<T>(allocator: dyn Allocator, count: usize): T[] | AllocError {
    if (count == 0) return [];
    unsafe {
        const raw = allocator.rawAlloc(count * @sizeOf(T), @alignOf(T)) ?? throw AllocError.OutOfMemory;
        const items = @ptrCast(T[*], raw);
        return items[0..count];
    }
}

/** `items` grown or shrunk to `count` values; the old slice must not be used afterwards. */
export function resize<T>(allocator: dyn Allocator, items: T[], count: usize): T[] | AllocError {
    if (count == 0) {
        free(allocator, items);
        return [];
    }
    if (items.len == 0) return alloc<T>(allocator, count);
    unsafe {
        const raw = allocator.rawResize(bytes(items), count * @sizeOf(T), @alignOf(T)) ?? throw AllocError.OutOfMemory;
        const resized = @ptrCast(T[*], raw);
        return resized[0..count];
    }
}

/** Gives memory from `alloc` or `resize` back. */
export function free<T>(allocator: dyn Allocator, items: T[]): void {
    if (items.len == 0) return;
    allocator.rawFree(bytes(items), @alignOf(T));
}

/** Room for one `T`, uninitialized. Release it with `destroy`. */
export function create<T>(allocator: dyn Allocator): *T | AllocError {
    unsafe {
        const raw = allocator.rawAlloc(@sizeOf(T), @alignOf(T)) ?? throw AllocError.OutOfMemory;
        return @ptrCast(*T, raw);
    }
}

/** Gives a value from `create` back. */
export function destroy<T>(allocator: dyn Allocator, item: *T): void {
    unsafe {
        const raw = @ptrCast(u8[*], item);
        allocator.rawFree(raw[0..@sizeOf(T)], @alignOf(T));
    }
}

/** The bytes under a slice. */
function bytes<T>(items: T[]): u8[] {
    unsafe {
        const raw = @ptrCast(u8[*], items.ptr);
        return raw[0..items.len * @sizeOf(T)];
    }
}

/** Copies `source` to the start of `dest`, which must be at least as long. */
function copy(dest: u8[], source: readonly u8[]): void {
    const _ = dest[0..source.len];   // bounds check
    unsafe {
        void c.memcpy(dest.ptr, source.ptr, source.len);
    }
}

/* ---- the C heap ---- */

/** malloc, realloc and free. Alignments up to 16 bytes, which is what malloc guarantees. */
export struct CAllocator {
    rawAlloc(this: *CAllocator, size: usize, align: usize): ?u8[*] {
        if (align > 16) return null;
        return c.malloc(size);
    }

    rawResize(this: *CAllocator, memory: u8[], size: usize, align: usize): ?u8[*] {
        if (align > 16) return null;
        return c.realloc(memory.ptr, size);
    }

    rawFree(this: *CAllocator, memory: u8[], _align: usize): void {
        c.free(memory.ptr);
    }
}

let cHeap: CAllocator = undefined;   // has no fields, so nothing to initialize

/** The C heap (malloc/free). */
export function cAllocator(): dyn Allocator {
    return &cHeap;
}

/* ---- arenas ---- */

const CHUNK_SIZE: usize = 4096;

/**
 * Hands out memory from big chunks taken from `backing`, and gives it all back at once in `deinit`. Freeing a
 * single allocation does nothing. Good for work whose memory all dies together: a request, a frame, a parse.
 */
export struct ArenaAllocator {
    backing: dyn Allocator,
    chunks: ArrayList<u8[]>,
    used: usize,            // bytes taken from the last chunk

    init(backing: dyn Allocator): ArenaAllocator {
        return ArenaAllocator { backing, chunks: ArrayList<u8[]>.init(backing), used: 0 };
    }

    allocator(this: *ArenaAllocator): dyn Allocator {
        return this;
    }

    /** Frees every allocation at once. */
    deinit(this: *ArenaAllocator): void {
        for (const chunk of this.chunks.items) this.backing.rawFree(chunk, 16);
        this.chunks.deinit();
        this.used = 0;
    }

    rawAlloc(this: *ArenaAllocator, size: usize, align: usize): ?u8[*] {
        if (align > 16) return null;
        const count = this.chunks.items.len;
        const start = (this.used + align - 1) / align * align;
        if (count > 0 && start + size <= this.chunks.items[count - 1].len) {
            this.used = start + size;
            return this.chunks.items[count - 1][start..start + size].ptr;
        }

        // A new chunk, at least twice the last one so big arenas need few of them.
        const last = count > 0 ? this.chunks.items[count - 1].len : CHUNK_SIZE / 2;
        const wanted = last * 2 > size ? last * 2 : size;
        unsafe {
            const raw = this.backing.rawAlloc(wanted, 16);
            if (raw == null) return null;
            const chunk = raw[0..wanted];
            this.chunks.append(chunk) catch {
                this.backing.rawFree(chunk, 16);
                return null;
            };
            this.used = size;
            return raw;
        }
    }

    rawResize(this: *ArenaAllocator, memory: u8[], size: usize, align: usize): ?u8[*] {
        if (size <= memory.len) return memory.ptr;
        unsafe {
            const raw = this.rawAlloc(size, align);
            if (raw == null) return null;
            copy(raw[0..size], memory);
            return raw;
        }
    }

    rawFree(this: *ArenaAllocator, _memory: u8[], _align: usize): void {}
}

/* ---- checking ---- */

// Guarded memory from the runtime (lib/rt/runtime.c): pages of its own per block, ending at an inaccessible page.
extern "C" function hx_guard_alloc(size: usize, align: usize): ?u8[*];
extern "C" function hx_guard_free(memory: u8[*], size: usize): void;

/**
 * Checks how memory is used. `deinit` reports every allocation that was never freed; freeing memory it didn't hand
 * out, freeing twice, or freeing with the wrong size panics. New memory is filled with 0xAA.
 *
 * Each block gets pages of its own on macOS and Linux, ending right before an inaccessible page, and freed blocks
 * become inaccessible without being reused. So reading or writing past the end of a block, using memory after
 * freeing it, and keeping a pointer into an ArrayList that has grown (and so moved) all panic where they happen,
 * with a stack trace. That costs at least a page per allocation: for programs with many live allocations,
 * `initUnguarded` keeps the other checks and takes memory from `backing` instead.
 */
export struct DebugAllocator {
    backing: dyn Allocator,
    live: ArrayList<u8[]>,  // allocations not yet freed
    guarded: bool,

    init(backing: dyn Allocator): DebugAllocator {
        return DebugAllocator { backing, live: ArrayList<u8[]>.init(backing), guarded: true };
    }

    /** The same checks, without page guards: blocks come from `backing`, and freed memory is filled with 0xAA. */
    initUnguarded(backing: dyn Allocator): DebugAllocator {
        return DebugAllocator { backing, live: ArrayList<u8[]>.init(backing), guarded: false };
    }

    allocator(this: *DebugAllocator): dyn Allocator {
        return this;
    }

    /** Reports each leak on stderr, frees it, and returns how many there were. */
    deinit(this: *DebugAllocator): usize {
        const leaks = this.live.items.len;
        for (const memory of this.live.items) {
            eprintln(`leak: ${memory.len} bytes were never freed`);
            this.release(memory, 16);
        }
        this.live.deinit();
        return leaks;
    }

    /** How many allocations are live right now. */
    count(this: readonly *DebugAllocator): usize {
        return this.live.items.len;
    }

    /** A block from the guarded pages, or from `backing`. */
    take(this: *DebugAllocator, size: usize, align: usize): ?u8[*] {
        if (this.guarded) return hx_guard_alloc(size, align);
        return this.backing.rawAlloc(size, align);
    }

    /** Gives a block back: to quarantine when guarded (inaccessible from now on), else to `backing`. */
    release(this: *DebugAllocator, memory: u8[], align: usize): void {
        if (this.guarded) {
            hx_guard_free(memory.ptr, memory.len);
            return;
        }
        fill(memory);
        this.backing.rawFree(memory, align);
    }

    rawAlloc(this: *DebugAllocator, size: usize, align: usize): ?u8[*] {
        unsafe {
            const raw = this.take(size, align);
            if (raw == null) return null;
            const memory = raw[0..size];
            this.live.append(memory) catch {
                this.release(memory, align);
                return null;
            };
            fill(memory);
            return raw;
        }
    }

    rawResize(this: *DebugAllocator, memory: u8[], size: usize, align: usize): ?u8[*] {
        const index = this.find(memory);
        unsafe {
            const raw = this.take(size, align);
            if (raw == null) return null;
            const moved = raw[0..size];
            fill(moved);
            copy(moved, size < memory.len ? memory[0..size] : memory);
            this.release(memory, align);
            this.live.items[index] = moved;   // always moves, so code that keeps the old slice breaks right away
            return raw;
        }
    }

    rawFree(this: *DebugAllocator, memory: u8[], align: usize): void {
        const index = this.find(memory);
        this.release(memory, align);
        const last = this.live.pop() ?? unreachable;
        if (index < this.live.items.len) this.live.items[index] = last;
    }

    /** Where `memory` is in `live`; panics if it isn't there. */
    find(this: readonly *DebugAllocator, memory: u8[]): usize {
        for (const live, i of this.live.items) {
            if (live.ptr != memory.ptr) continue;
            if (live.len != memory.len) @panic("memory freed or resized with a different size than it has");
            return i;
        }
        @panic("memory freed twice, or not from this allocator");
    }
}

/** Fills memory with 0xAA, the pattern for "undefined". */
function fill(memory: u8[]): void {
    for (const _, i of memory) memory[i] = 0xAA;
}
