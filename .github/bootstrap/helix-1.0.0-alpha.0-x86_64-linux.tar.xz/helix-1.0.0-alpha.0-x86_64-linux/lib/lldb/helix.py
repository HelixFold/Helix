"""lldb formatters for Helix programs.

Load once per session with `command script import <helix>/lib/lldb/helix.py`, or add that
line to ~/.lldbinit. Shows strings as text, slices as their elements, optionals as the
value or `null`, and error unions as the value or `error.Name`.
"""

import re

import lldb

STRING = r"^(readonly )?u8\[\]$|^string$"
SLICE = r"^(readonly )?.+\[\]$"
OPTIONAL = r"^\?"
ERROR_UNION = r" \| "

MAX_STRING = 1024
MAX_CHILDREN = 256


def describe(value):
    """A one-line description of `value`, like lldb's own display of it."""
    summary = value.GetSummary()
    if summary is not None:
        return summary
    text = value.GetValue()
    return text if text is not None else ""   # an aggregate: its children show it


def string_summary(value, _internal):
    value = value.GetNonSyntheticValue()
    ptr = value.GetChildMemberWithName("ptr")
    length = value.GetChildMemberWithName("len").GetValueAsUnsigned()
    if length == 0:
        return '""'
    error = lldb.SBError()
    data = value.GetProcess().ReadMemory(ptr.GetValueAsUnsigned(), min(length, MAX_STRING), error)
    if not error.Success():
        return "<unreadable>"
    text = data.decode("utf-8", errors="replace")
    text = text.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\t", "\\t")
    return '"' + text + ('..."' if length > MAX_STRING else '"')


class SliceChildren:
    """A slice's elements, as if it were an array of `len` items."""

    def __init__(self, value, _internal):
        self.value = value

    def update(self):
        self.ptr = self.value.GetChildMemberWithName("ptr")
        self.length = self.value.GetChildMemberWithName("len").GetValueAsUnsigned()
        self.element = self.ptr.GetType().GetPointeeType()
        return False

    def num_children(self):
        return min(self.length, MAX_CHILDREN)

    def get_child_index(self, name):
        try:
            return int(name.lstrip("[").rstrip("]"))
        except ValueError:
            return -1

    def get_child_at_index(self, index):
        if index < 0 or index >= self.num_children():
            return None
        address = self.ptr.GetValueAsUnsigned() + index * self.element.GetByteSize()
        return self.value.CreateValueFromAddress("[%d]" % index, address, self.element)

    def has_children(self):
        return True


def slice_summary(value, _internal):
    return "len=%d" % value.GetNonSyntheticValue().GetChildMemberWithName("len").GetValueAsUnsigned()


def payload(value):
    """The value inside an optional or error union, or None when there is none."""
    value = value.GetNonSyntheticValue()
    present = value.GetChildMemberWithName("present")
    if present.IsValid():
        return value.GetChildMemberWithName("value") if present.GetValueAsUnsigned() != 0 else None
    error = value.GetChildMemberWithName("error")
    if error.IsValid():
        return value.GetChildMemberWithName("value") if error.GetValueAsUnsigned() == 0 else None
    return None


class PayloadChildren:
    """An optional's or error union's value shows its fields directly, without a wrapper."""

    def __init__(self, value, _internal):
        self.value = value
        self.inner = None

    def update(self):
        self.inner = payload(self.value)
        # A string inside shows as text alone, the way its own summary hides its fields.
        if self.inner is not None and re.search(STRING, self.inner.GetTypeName()):
            self.inner = None
        return False

    def num_children(self):
        return self.inner.GetNumChildren() if self.inner is not None else 0

    def get_child_index(self, name):
        return self.inner.GetIndexOfChildWithName(name) if self.inner is not None else -1

    def get_child_at_index(self, index):
        return self.inner.GetChildAtIndex(index) if self.inner is not None else None

    def has_children(self):
        return self.inner is not None and self.inner.MightHaveChildren()


def optional_summary(value, _internal):
    raw = value.GetNonSyntheticValue()
    if not raw.GetChildMemberWithName("present").IsValid():
        # An optional pointer is the pointer itself, null when absent.
        return "null" if raw.GetValueAsUnsigned() == 0 else ""
    inner = payload(raw)
    return describe(inner) if inner is not None else "null"


def error_union_summary(value, _internal):
    raw = value.GetNonSyntheticValue()
    error = raw.GetChildMemberWithName("error")
    if not error.IsValid():
        return ""
    if error.GetValueAsUnsigned() != 0:
        return "error." + (error.GetValue() or str(error.GetValueAsUnsigned()))
    return describe(raw.GetChildMemberWithName("value"))


def __lldb_init_module(debugger, _internal):
    category = debugger.CreateCategory("helix")

    def summary(pattern, function, options=lldb.eTypeOptionCascade):
        category.AddTypeSummary(lldb.SBTypeNameSpecifier(pattern, True),
                                lldb.SBTypeSummary.CreateWithFunctionName("helix." + function, options))

    def children(pattern, provider):
        category.AddTypeSynthetic(lldb.SBTypeNameSpecifier(pattern, True),
                                  lldb.SBTypeSynthetic.CreateWithClassName("helix." + provider, lldb.eTypeOptionCascade))

    # Bytes are numbers, not C chars.
    category.AddTypeFormat(lldb.SBTypeNameSpecifier("u8"), lldb.SBTypeFormat(lldb.eFormatUnsigned, lldb.eTypeOptionSkipPointers))
    category.AddTypeFormat(lldb.SBTypeNameSpecifier("i8"), lldb.SBTypeFormat(lldb.eFormatDecimal, lldb.eTypeOptionSkipPointers))
    # Strings come first: a string is also a slice, and the first match wins.
    summary(STRING, "string_summary", lldb.eTypeOptionCascade | lldb.eTypeOptionHideChildren)
    summary(SLICE, "slice_summary")
    children(SLICE, "SliceChildren")
    summary(OPTIONAL, "optional_summary")
    children(OPTIONAL, "PayloadChildren")
    summary(ERROR_UNION, "error_union_summary")
    children(ERROR_UNION, "PayloadChildren")
    category.SetEnabled(True)
