/**
 * Memory-mapped registers: what a microcontroller's peripherals are, as `helix translate-svd` describes them.
 *
 *   RCC.AHB1ENR.set(.GPIOAEN);            // one field, by name: read, change those bits, write back
 *   GPIOA.MODER.modify(.MODER9, 2);
 *   while (USART1.SR.get(.TXE) == 0) {}
 *   USART1.DR.write(byte);                // the whole register
 *
 * `F` is the register's own enum of fields, each member's value its position: bits 0-7 the lowest bit, bits 8-15
 * the width. Every access is a volatile load or store of the register's width, so none is merged or dropped.
 */

/** A field's mask, in place. */
function maskOf(field: u32): u32 {
    const width = (field >> 8) & 0xFF;
    const ones: u32 = width >= 32 ? 0xFFFF_FFFF : ((1 as u32) << width) - 1;
    return ones << (field & 0xFF);
}

/** A 32-bit register. */
export struct Register<F> {
    address: usize,

    read(this: Register<F>): u32 {
        unsafe {
            return @volatileLoad(@ptrFromInt(*u32, this.address));
        }
    }

    write(this: Register<F>, value: u32): void {
        unsafe {
            @volatileStore(@ptrFromInt(*u32, this.address), value);
        }
    }

    /** A field's value, shifted down. */
    get(this: Register<F>, field: F): u32 {
        const f = field as u32;
        return (this.read() & maskOf(f)) >> (f & 0xFF);
    }

    /** Sets a field to `value`, leaving the others: read, change, write. */
    modify(this: Register<F>, field: F, value: u32): void {
        const f = field as u32;
        this.write((this.read() & ~maskOf(f)) | ((value << (f & 0xFF)) & maskOf(f)));
    }

    /** Every bit of a field to 1 (a one-bit field: on). */
    set(this: Register<F>, field: F): void {
        this.write(this.read() | maskOf(field as u32));
    }

    /** Every bit of a field to 0. */
    clear(this: Register<F>, field: F): void {
        this.write(this.read() & ~maskOf(field as u32));
    }
}

/** A 16-bit register: some peripherals take only accesses of their width. */
export struct Register16<F> {
    address: usize,

    read(this: Register16<F>): u32 {
        unsafe {
            return @volatileLoad(@ptrFromInt(*u16, this.address)) as u32;
        }
    }

    write(this: Register16<F>, value: u32): void {
        unsafe {
            @volatileStore(@ptrFromInt(*u16, this.address), @truncate(u16, value));
        }
    }

    /** A field's value, shifted down. */
    get(this: Register16<F>, field: F): u32 {
        const f = field as u32;
        return (this.read() & maskOf(f)) >> (f & 0xFF);
    }

    /** Sets a field to `value`, leaving the others: read, change, write. */
    modify(this: Register16<F>, field: F, value: u32): void {
        const f = field as u32;
        this.write((this.read() & ~maskOf(f)) | ((value << (f & 0xFF)) & maskOf(f)));
    }

    /** Every bit of a field to 1 (a one-bit field: on). */
    set(this: Register16<F>, field: F): void {
        this.write(this.read() | maskOf(field as u32));
    }

    /** Every bit of a field to 0. */
    clear(this: Register16<F>, field: F): void {
        this.write(this.read() & ~maskOf(field as u32));
    }
}

/** A 8-bit register: some peripherals take only accesses of their width. */
export struct Register8<F> {
    address: usize,

    read(this: Register8<F>): u32 {
        unsafe {
            return @volatileLoad(@ptrFromInt(*u8, this.address)) as u32;
        }
    }

    write(this: Register8<F>, value: u32): void {
        unsafe {
            @volatileStore(@ptrFromInt(*u8, this.address), @truncate(u8, value));
        }
    }

    /** A field's value, shifted down. */
    get(this: Register8<F>, field: F): u32 {
        const f = field as u32;
        return (this.read() & maskOf(f)) >> (f & 0xFF);
    }

    /** Sets a field to `value`, leaving the others: read, change, write. */
    modify(this: Register8<F>, field: F, value: u32): void {
        const f = field as u32;
        this.write((this.read() & ~maskOf(f)) | ((value << (f & 0xFF)) & maskOf(f)));
    }

    /** Every bit of a field to 1 (a one-bit field: on). */
    set(this: Register8<F>, field: F): void {
        this.write(this.read() | maskOf(field as u32));
    }

    /** Every bit of a field to 0. */
    clear(this: Register8<F>, field: F): void {
        this.write(this.read() & ~maskOf(field as u32));
    }
}

/* ---- the Cortex-M interrupt controller (NVIC) ---- */

const NVIC_ISER: usize = 0xE000_E100;   // set-enable
const NVIC_ICER: usize = 0xE000_E180;   // clear-enable
const NVIC_ISPR: usize = 0xE000_E200;   // set-pending
const NVIC_ICPR: usize = 0xE000_E280;   // clear-pending

/** One bit for interrupt `n` in a bank of 32-bit NVIC registers. */
function nvicBit(bank: usize, n: u32): void {
    unsafe {
        @volatileStore(@ptrFromInt(*u32, bank + ((n / 32) as usize) * 4), (1 as u32) << (n % 32));
    }
}

/** Lets interrupt `n` reach its handler (`IRQ<n>_Handler`). Generated chip modules wrap these with their names. */
export function nvicEnable(n: u32): void {
    nvicBit(NVIC_ISER, n);
}

export function nvicDisable(n: u32): void {
    nvicBit(NVIC_ICER, n);
}

/** Raises interrupt `n` from software. */
export function nvicSetPending(n: u32): void {
    nvicBit(NVIC_ISPR, n);
}

export function nvicClearPending(n: u32): void {
    nvicBit(NVIC_ICPR, n);
}

/* ---- SysTick: the timer every Cortex-M has (it's the core's, so chips' SVD files leave it out) ---- */

export enum SystCsr: u32 {
    ENABLE = 0x0100,        // bit 0: counting
    TICKINT = 0x0101,       // bit 1: an interrupt (SysTick_Handler) at each wrap
    CLKSOURCE = 0x0102,     // bit 2: the processor's clock (else a slower reference)
    COUNTFLAG = 0x0110,     // bit 16: wrapped since last read
}

export enum SystRvr: u32 {
    RELOAD = 0x1800,        // bits 0-23: counts from here down to 0
}

export enum SystCvr: u32 {
    CURRENT = 0x1800,       // bits 0-23
}

export struct SysTick {
    CSR: Register<SystCsr>,
    RVR: Register<SystRvr>,
    CVR: Register<SystCvr>,
}

export const SYSTICK: SysTick = SysTick {
    CSR: Register<SystCsr> { address: 0xE000_E010 },
    RVR: Register<SystRvr> { address: 0xE000_E014 },
    CVR: Register<SystCvr> { address: 0xE000_E018 },
};
