/** The program `helix build` compiles together with a project's build.hx, imported as the package "@build". */

import { Init } from "./process";
import { runBuild } from "./build";
import { build } from "@build";

export function main(init: Init): u8 | Error {
    return try runBuild(init, build);
}
